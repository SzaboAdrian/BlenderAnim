# Representative native EEVEE frames

960 × 540, 24 render samples; these are rendered from the delivered project.

- [00121.png](00121.png) — 5.00 s: Rainy opening and bus shelter.
- [00265.png](00265.png) — 11.00 s: Noticing smile.
- [00573.png](00573.png) — 23.83 s: Concern and question.
- [00697.png](00697.png) — 29.00 s: Hesitant reply with readable subtitle.
- [00849.png](00849.png) — 35.33 s: Standing, bus waiting with door open.
- [00951.png](00951.png) — 39.58 s: Approaching the boarding steps.
- [01011.png](01011.png) — 42.08 s: Entering the real bus doorway.
- [01291.png](01291.png) — 53.75 s: Single keyboard press.
- [01393.png](01393.png) — 58.00 s: Studio overview and active DAW display.
- [01497.png](01497.png) — 62.33 s: Turning the audio controller.
- [01747.png](01747.png) — 72.75 s: Quiet studio portrait.
- [02137.png](02137.png) — 89.00 s: Greeting the audience.
- [02497.png](02497.png) — 104.00 s: Dream concert and closing words.
