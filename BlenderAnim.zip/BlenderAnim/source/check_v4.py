"""Check the actual gesture joints, timing, camera hold and portable resources."""
from pathlib import Path
import json
import math
import bpy
from mathutils import Vector

scene=bpy.context.scene
assert scene.frame_end==2712 and scene.render.fps==24
assert not any(o.get('shirt_print') for o in scene.objects)
assert len([o for o in scene.objects if o.get('weather_v4') and 'falling rain' in o.name])==4
assert scene.timeline_markers['11 Drone pull away'].frame==2233
assert scene['closing_quote']=='Maybe in another life, there will be an opportunity, to be more than a dreamer, Adrian'
errors=[];heights={};previous={};smallest_dot=1.0;smallest_when=None
for frame in range(2064,2713):
    scene.frame_set(frame)
    for suffix in ('','.001'):
        upper=scene.objects['Narrator on stage upper arm'+suffix]
        lower=scene.objects['Narrator on stage forearm'+suffix]
        hand=scene.objects['Narrator on stage hand'+suffix]
        end_upper=upper.matrix_local@Vector((0,0,.155))
        start_lower=lower.matrix_local@Vector((0,0,-.16))
        end_lower=lower.matrix_local@Vector((0,0,.16))
        errors.extend([(end_upper-start_lower).length,(end_lower-hand.location).length])
        for obj in (upper,lower,hand):
            q=obj.rotation_quaternion.copy()
            if obj.name in previous and q.dot(previous[obj.name])<smallest_dot:
                smallest_dot=q.dot(previous[obj.name]);smallest_when=(frame,obj.name)
            previous[obj.name]=q
    if frame in [2065,2101,2137,2173,2209,2233]:heights[frame]=float(scene.objects['Narrator on stage hand.001'].location.z)
assert max(errors)<.00002, max(errors)
assert smallest_dot>.98,(smallest_dot,smallest_when)
assert heights[2101]>1.78 and heights[2137]>1.78
assert heights[2209]<.8 and heights[2233]<.8
camera=next(m.camera for m in scene.timeline_markers if m.frame==1849)
scene.frame_set(2065);matrix=camera.matrix_world.copy()
scene.frame_set(2232)
assert max(abs(camera.matrix_world[i][j]-matrix[i][j]) for i in range(4) for j in range(4))<1e-5
for frame,sector in [(51,0),(1743,1),(2157,2),(2545,2)]:
    scene.frame_set(frame)
    for obj in scene.objects:
        if obj.get('portrait_v4') and 'render_sector' in obj:assert obj.hide_render==(obj['render_sector']!=sector)
for sound in bpy.data.sounds:
    if sound.users:assert Path(bpy.path.abspath(sound.filepath)).is_file()
title=next(i for i in bpy.data.images if i.name.startswith('Closing words |'))
assert title.packed_file
scene.frame_set(2350);assert scene.node_tree.nodes['Closing words opacity'].outputs[0].default_value==0
scene.frame_set(2500);assert scene.node_tree.nodes['Closing words opacity'].outputs[0].default_value>.99
report={'end_frame':2712,'seconds':113,'drone_start':2233,'hand_lowered_by':2209,
        'max_joint_gap_m':max(errors),'min_adjacent_quaternion_dot':smallest_dot,
        'right_wrist_height_local':heights,'shirt_print_count':0,'packed_title':True}
output=Path(bpy.data.filepath).parent/'motion_validation_v4.json'
output.write_text(json.dumps(report,indent=2))
print('V4_ACTUAL_MOTION_VERIFIED',json.dumps(report),flush=True)
