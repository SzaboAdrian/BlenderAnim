"""Finish cached 3D plates with the same display grade and packed artwork.

The shirt print is projected from its actual animated Blender plane. Scene
raycasts mask it behind hands, the desk, and other geometry. Everything also
exists in film_render_v3.blend for an ordinary full native Blender render.
"""
from pathlib import Path
import json
import math
import sys
import time

import bpy
import numpy as np
from bpy_extras.object_utils import world_to_camera_view
from mathutils import Vector
from PIL import Image

BASE = Path(__file__).resolve().parent
if BASE.name == 'source':
    BASE = BASE.parent
OUT = BASE / 'output'
DESTINATION = OUT / 'melancholy_frames'
WIDTH, HEIGHT = 960, 540


def grade(rgb):
    gray = np.sum(rgb * np.array([.2126, .7152, .0722]), axis=-1, keepdims=True)
    muted = gray + .72 * (rgb - gray)
    lift = np.sin(math.pi * muted)
    soft = muted * .92 + .07 * lift
    return np.clip(soft * np.array([.94, .96, 1.02]) + lift * np.array([-.035, -.015, .065]), 0, 1)


def homography(screen, uv):
    rows, answers = [], []
    for (x, y), (u, v) in zip(screen, uv):
        rows.extend([[x, y, 1, 0, 0, 0, -u*x, -u*y],
                     [0, 0, 0, x, y, 1, -v*x, -v*y]])
        answers.extend([u, v])
    return np.linalg.solve(np.array(rows), np.array(answers))


def projected_print(scene, depsgraph, obj, mask, ink):
    """Return a small screen-space RGBA patch with correct geometry occlusion."""
    corners = [obj.matrix_world @ vertex.co for vertex in obj.data.vertices]
    normal = (corners[1] - corners[0]).cross(corners[2] - corners[0])
    origin = scene.camera.matrix_world.translation
    if normal.length < 1e-10 or normal.dot(origin - corners[0]) <= 0:
        return None
    projected = [world_to_camera_view(scene, scene.camera, p) for p in corners]
    if any(p.z < scene.camera.data.clip_start for p in projected):
        return None
    coords = [(p.x * WIDTH, (1-p.y) * HEIGHT) for p in projected]
    x0 = max(0, math.floor(min(p[0] for p in coords))-1)
    x1 = min(WIDTH, math.ceil(max(p[0] for p in coords))+1)
    y0 = max(0, math.floor(min(p[1] for p in coords))-1)
    y1 = min(HEIGHT, math.ceil(max(p[1] for p in coords))+1)
    if x1 <= x0 or y1 <= y0:
        return None
    # Supersample the small patch, then reduce its alpha for clean subpixel ink.
    factor = 3
    local = [((x-x0)*factor, (y-y0)*factor) for x, y in coords]
    transform = homography(local, [(0, mask.height), (mask.width, mask.height),
                                   (mask.width, 0), (0, 0)])
    alpha = mask.transform(((x1-x0)*factor, (y1-y0)*factor), Image.Transform.PERSPECTIVE,
                           tuple(transform), resample=Image.Resampling.BICUBIC)
    alpha = alpha.resize((x1-x0, y1-y0), Image.Resampling.LANCZOS)
    values = np.array(alpha, dtype=np.float32) / 255
    inv = homography(coords, [(0, 0), (1, 0), (1, 1), (0, 1)])
    for py, px in np.argwhere(values > .015):
        x, y = x0 + px + .5, y0 + py + .5
        den = inv[6]*x + inv[7]*y + 1
        u = (inv[0]*x + inv[1]*y + inv[2]) / den
        v = (inv[3]*x + inv[4]*y + inv[5]) / den
        point = corners[0] + (corners[1]-corners[0])*u + (corners[3]-corners[0])*v
        ray = point - origin
        distance = ray.length
        hit, location, _, _, other, _ = scene.ray_cast(depsgraph, origin, ray.normalized(), distance=max(0, distance-.001))
        if hit and not other.hide_render:
            values[py, px] = 0
    return x0, y0, values[..., None], ink


def finish(frame, scene, mask, lookup, title, destination):
    scene.frame_set(frame)
    depsgraph = bpy.context.evaluated_depsgraph_get()
    rgb = np.asarray(Image.open(OUT / 'final_frames' / f'{frame:05d}.png').convert('RGB'), dtype=np.float32) / 255
    sector = 0 if frame < 1249 else 1 if frame < 1849 else 2
    fade = scene.node_tree.nodes['Editorial fades'].inputs[2].default_value[0]
    ink = lookup[min(1023, max(0, round(float(fade)*1023)))]
    for obj in scene.objects:
        if obj.get('shirt_print') and obj.get('render_sector') == sector:
            patch = projected_print(scene, depsgraph, obj, mask, ink)
            if patch is not None:
                x, y, alpha, color = patch
                part = rgb[y:y+alpha.shape[0], x:x+alpha.shape[1]]
                part[:] = part * (1-alpha) + color * alpha
    rgb = grade(rgb)
    visibility = scene.node_tree.nodes['Closing words opacity'].outputs[0].default_value
    if visibility > 0:
        alpha = title[..., 3:4] * visibility
        rgb = rgb * (1-alpha) + title[..., :3] * alpha
    Image.fromarray(np.uint8(np.clip(rgb, 0, 1)*255 + .5)).save(destination, compress_level=2)


if __name__ == '__main__':
    args = sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
    proof = bool(args and args[0] == 'proof')
    frames = [int(f) for f in args[1:]] if proof else range(1, 2617, 2)
    DESTINATION = OUT / ('v3_cached_proofs' if proof else 'melancholy_frames')
    DESTINATION.mkdir(exist_ok=True)
    scene = bpy.context.scene
    scene.render.resolution_x = WIDTH; scene.render.resolution_y = HEIGHT; scene.render.resolution_percentage = 100
    mask = Image.open(OUT / 'assets_v3' / 'adrian_shirt.png').getchannel('A')
    lookup = np.asarray(Image.open(OUT / 'assets_v3' / 'ink_agx_lookup.png').convert('RGB'), dtype=np.float32)[8] / 255
    title = np.asarray(Image.open(OUT / 'assets_v3' / 'closing_title.png').resize((WIDTH, HEIGHT), Image.Resampling.LANCZOS), dtype=np.float32) / 255
    start = time.time()
    for count, frame in enumerate(frames):
        if 1705 <= frame < 1849:
            continue  # This camera changed and receives a native 3D render.
        destination = DESTINATION / f'{frame:05d}.png'
        if not destination.exists():
            finish(frame, scene, mask, lookup, title, destination)
        if count % 48 == 0 or proof:
            print('FINISHED_PLATE', frame, 'seconds', round(time.time()-start, 2), flush=True)
    print('CACHED_FINISH_DONE', flush=True)
