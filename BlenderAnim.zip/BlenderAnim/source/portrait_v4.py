"""A continuous sculpted face, inset almond eyes and short dark-brown fringe.

Coordinates are local to the existing animated head pivot; forward is -Y.
The nose belongs to the face mesh. Lips and eyelids are shallow surface ribbons,
not separate cylinders. The existing performance can therefore be reused.
"""
import math
import random
import bpy
from mathutils import Vector


def mat(name, color, rough=.6, spec=.25):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.use_nodes = True
    m.diffuse_color = (*color, 1)
    p = m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value = (*color, 1)
    p.inputs['Roughness'].default_value = rough
    p.inputs['Specular IOR Level'].default_value = spec
    return m


PROFILE = [(-.265,.018,.040,.012),(-.242,.082,.093,.008),
           (-.208,.119,.114,.006),(-.150,.148,.135,.008),
           (-.070,.174,.151,.012),(.020,.181,.158,.014),
           (.110,.180,.159,.018),(.190,.165,.148,.022),
           (.248,.120,.111,.026),(.280,.018,.026,.026)]


def profile(z, channel):
    for i in range(len(PROFILE)-1):
        a, b = PROFILE[i], PROFILE[i+1]
        if z <= b[0]:
            t = max(0, min(1, (z-a[0])/(b[0]-a[0])))
            before = PROFILE[max(0,i-1)]; after = PROFILE[min(len(PROFILE)-1,i+2)]
            ma = (b[channel]-before[channel])/(b[0]-before[0])
            mb = (after[channel]-a[channel])/(after[0]-a[0])
            return (2*t**3-3*t*t+1)*a[channel] + (t**3-2*t*t+t)*(b[0]-a[0])*ma + (-2*t**3+3*t*t)*b[channel] + (t**3-t*t)*(b[0]-a[0])*mb
    return PROFILE[-1][channel]


def sculpt(x,z):
    def g(cx,cz,wx,wz):
        return math.exp(-((x-cx)/wx)**2-((z-cz)/wz)**2)
    result = -.021*g(0,.000,.019,.064) - .040*g(0,-.064,.024,.024)
    result -= .009*(g(-.026,-.075,.016,.014)+g(.026,-.075,.016,.014))
    result -= .008*(g(-.102,-.058,.061,.048)+g(.102,-.058,.061,.048))
    result += .003*(g(-.070,.030,.045,.030)+g(.070,.030,.045,.030))
    result -= .004*(g(-.068,.080,.060,.018)+g(.068,.080,.060,.018))
    result -= .005*g(0,-.137,.070,.039)
    return result


def face_y(x,z):
    rx,ry,cy = [profile(z,i) for i in (1,2,3)]
    c = math.sqrt(max(0,1-(x/max(.001,rx))**2))
    return cy-ry*c+sculpt(x,z)*c**4


def create_portrait(head, sector):
    scene = bpy.context.scene
    skin = mat('V4 natural warm skin',(.51,.315,.23),.57,.28)
    skin.node_tree.nodes['Principled BSDF'].inputs['Subsurface Weight'].default_value = .055
    lips = mat('V4 muted natural lips',(.35,.157,.137),.62,.22)
    crease = mat('V4 soft facial creases',(.16,.071,.049),.85,.1)
    hair = mat('V4 very dark brown hair',(.012,.0085,.0065),.82,.09)
    hair_light = mat('V4 subtle brown hair fibres',(.021,.014,.010),.82,.09)
    brows = mat('V4 dark brows',(.016,.010,.007),.85,.12)
    white = mat('V4 warm eye whites',(.56,.535,.49),.30,.40)
    iris = mat('V4 brown iris',(.039,.020,.010),.36,.35)
    rim = mat('V4 iris outer ring',(.016,.009,.005),.40,.3)
    pupil = mat('V4 pupils',(.003,.002,.0015),.3,.4)
    glint = mat('V4 small eye highlights',(.82,.83,.81),.2,.5)
    made=[]

    def mesh(name,verts,faces,material,parent=head):
        data=bpy.data.meshes.new(name); data.from_pydata(verts,[],faces); data.update()
        obj=bpy.data.objects.new(head.name+' | '+name,data); scene.collection.objects.link(obj)
        obj.parent=parent; data.materials.append(material)
        for p in data.polygons:p.use_smooth=True
        obj['portrait_v4']=True; obj['render_sector']=sector; made.append(obj)
        return obj

    def ell(name,center,scale,material):
        vertices=[]; faces=[]; n=40; rows=24
        for j in range(rows+1):
            phi=math.pi*j/rows
            for i in range(n):
                a=math.tau*i/n
                vertices.append((center[0]+scale[0]*math.sin(phi)*math.cos(a),
                                 center[1]+scale[1]*math.sin(phi)*math.sin(a),
                                 center[2]+scale[2]*math.cos(phi)))
        for j in range(rows):
            for i in range(n):
                a=j*n+i;b=j*n+(i+1)%n;faces.append((a,b,b+n,a+n))
        return mesh(name,vertices,faces,material)

    def line(name,points,width,material,radii=None):
        data=bpy.data.curves.new(name,'CURVE');data.dimensions='3D';data.bevel_depth=width;data.bevel_resolution=2
        spline=data.splines.new('BEZIER');spline.bezier_points.add(len(points)-1)
        for i,(p,co) in enumerate(zip(spline.bezier_points,points)):
            p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
            if radii:p.radius=radii[i]
        obj=bpy.data.objects.new(head.name+' | '+name,data);scene.collection.objects.link(obj);obj.parent=head
        data.materials.append(material);obj['portrait_v4']=True;obj['render_sector']=sector;made.append(obj)
        return obj

    vertices=[];faces=[];n=128;rows=100
    for j in range(rows+1):
        z=-.265+.545*j/rows;rx,ry,cy=[profile(z,i) for i in (1,2,3)]
        for i in range(n):
            theta=math.tau*i/n;c=math.cos(theta);x=rx*math.sin(theta)
            y=cy-ry*c+sculpt(x,z)*max(0,c)**4
            vertices.append((x,y,z))
    for j in range(rows):
        for i in range(n):
            a=j*n+i;b=j*n+(i+1)%n;faces.append((a,b,b+n,a+n))
    faces.extend([tuple(reversed(range(n))),tuple(rows*n+i for i in range(n))])
    mesh('Continuous face, nose and jaw',vertices,faces,skin)
    ell('Neck',(0,.025,-.302),(.078,.075,.105),skin)
    for side in (-1,1):
        ell('Ear',(side*.177,.015,-.025),(.027,.021,.057),skin)
        ell('Ear inner fold',(side*.192,-.002,-.023),(.008,.005,.030),lips)

    # Eyes are shallow almond surfaces embedded in the facial surface.
    for side in (-1,1):
        cx=side*.069;cz=.027
        eye=bpy.data.objects.new(head.name+f' | eye pivot {side}',None);scene.collection.objects.link(eye)
        eye.parent=head;eye.location=(cx,0,cz);eye['portrait_v4']=True
        def eye_surface(x,z,bulge=.0065):
            radius=((x-cx)/.037)**2+((z-cz)/.014)**2
            return face_y(x,z)-.001-bulge*max(0,1-radius)
        def shape(t,r=1):
            x=cx+.037*math.cos(t)*r
            z=cz+(.014 if math.sin(t)>0 else .010)*math.sin(t)*r+side*(x-cx)*.055
            return x,z
        verts=[];fs=[];nr=9;nt=64
        for j in range(nr+1):
            for i in range(nt):
                x,z=shape(math.tau*i/nt,j/nr)
                verts.append((x-cx,eye_surface(x,z),z-cz))
        for j in range(nr):
            for i in range(nt):
                a=j*nt+i;b=j*nt+(i+1)%nt;fs.append((a,b,b+nt,a+nt))
        mesh('Inset almond eye',verts,fs,white,eye)
        # Concentric iris bands; a small corneal highlight adds life without a bulging eyeball.
        for label,radius,material,extra in [('Iris rim',.0112,rim,.0003),('Brown iris',.0099,iris,.0005),('Pupil',.0049,pupil,.0007)]:
            vs=[(0,eye_surface(cx,cz)-extra,0)]
            for k in range(64):
                t=math.tau*k/64;x=cx+radius*math.cos(t);z=cz+radius*math.sin(t)
                vs.append((x-cx,eye_surface(x,z)-extra,z-cz))
            mesh(label,vs,[(0,k+1,(k+1)%64+1) for k in range(64)],material,eye)
        gx=cx-.003;gz=cz+.004
        vs=[(gx-cx,eye_surface(gx,gz)-.0011,gz-cz)]
        for k in range(24):
            a=math.tau*k/24;x=gx+.0014*math.cos(a);z=gz+.0014*math.sin(a)
            vs.append((x-cx,eye_surface(x,z)-.0011,z-cz))
        mesh('Tiny corneal catchlight',vs,[(0,k+1,(k+1)%24+1) for k in range(24)],glint,eye)
        # The upper and lower lids sit flush with the face and cover the iris edges.
        verts=[];fs=[]
        for j in range(4):
            r=1+j*.11
            for k in range(nt):
                t=math.tau*k/nt;x,z=shape(t,r)
                verts.append((x-cx,face_y(x,z)-.0012-.0015*math.sin(math.pi*j/3),z-cz))
        for j in range(3):
            for k in range(nt):
                a=j*nt+k;b=j*nt+(k+1)%nt;fs.append((a,b,b+nt,a+nt))
        mesh('Soft eyelid rim',verts,fs,skin,eye)
        # Occasional relaxed blinks, with no movement during the final text hold.
        for f in [1,2712]:eye.scale=(1,1,1);eye.keyframe_insert('scale',frame=f)
        for f in [398,602,777,1072,1203,1398,1642,1775,2028,2180,2437]:
            for at,zscale in [(f-3,1),(f,.08),(f+3,1)]:
                eye.scale=(1,1,zscale);eye.keyframe_insert('scale',frame=at)
        for fc in eye.animation_data.action.fcurves:
            for key in fc.keyframe_points:key.interpolation='BEZIER';key.handle_left_type='AUTO_CLAMPED';key.handle_right_type='AUTO_CLAMPED'
        # Tapered eyebrow ribbons, with no round rod ends.
        vs=[];fs=[];segments=32
        for i in range(segments+1):
            t=i/segments;x=side*(.027+.101*t);z=.079+.011*math.sin(t*math.pi)-.009*t
            thickness=.0075*math.sin(math.pi*(.10+.88*t))**.45
            for k in [-1,1]:
                zz=z+k*thickness/2;vs.append((x,face_y(x,zz)-.002,zz))
        for i in range(segments):a=i*2;fs.append((a,a+1,a+3,a+2))
        mesh('Tapered dark eyebrow',vs,fs,brows)

    # Lips are continuous shallow patches, with tapered corners and a fine seam.
    def seam(x):return -.151-.0023*math.cos(x/.048*math.pi/2)
    for upper in (True,False):
        vs=[];fs=[];segments=64;bands=7
        for i in range(segments+1):
            x=-.048+.096*i/segments;t=x/.048;taper=max(0,1-t*t)**.8
            edge=seam(x)+(1 if upper else -1)*(.0055 if upper else .0075)*taper
            if upper:edge+=.0017*math.exp(-((abs(x)-.012)/.009)**2)
            for j in range(bands+1):
                u=j/bands;z=seam(x)*(1-u)+edge*u
                y=face_y(x,z)-.0005-.0045*taper*math.sin(math.pi*(u*.7+.2))
                vs.append((x,y,z))
        for i in range(segments):
            for j in range(bands):a=i*(bands+1)+j;fs.append((a,a+bands+1,a+bands+2,a+1))
        mesh('Upper lip' if upper else 'Lower lip',vs,fs,lips)
    points=[]
    for i in range(13):
        x=-.047+.094*i/12;z=seam(x);points.append((x,face_y(x,z)-.004,z))
    line('Fine closed mouth seam',points,.00065,crease,[math.sin(math.pi*i/12)**.5 for i in range(13)])
    for side in (-1,1):
        vs=[]
        for k in range(32):
            a=math.tau*k/32;x=side*.020+.0047*math.cos(a);z=-.082+.0028*math.sin(a)
            vs.append((x,face_y(x,z)-.0008,z))
        mesh('Subtle nostril',vs,[tuple(range(32))],crease)

    # An organic cap, flat tapered fringe locks and fine dark fibres replace the
    # previous spherical bangs and raised bright tubes.
    def cap(a,p):
        ripple=.0015*math.sin(a*17+p*6)+.0008*math.sin(a*31-p*4)
        z=.025+(.278+ripple)*math.cos(p)
        # Follow the actual sculpted skull profile; a simple ellipsoid pierced
        # the wider upper forehead. The offset keeps a continuous scalp cover.
        skull_z=min(.279,z-.024)
        rx=profile(skull_z,1)+.010+ripple
        ry=profile(skull_z,2)+.010+ripple
        cy=profile(skull_z,3)+.002
        pole=min(1,p/.12)
        return (rx*pole*math.sin(a),cy-ry*pole*math.cos(a),z)
    vs=[];fs=[];nt=128;nr=32
    for j in range(nr+1):
        for i in range(nt):
            a=math.tau*i/nt;end=1.55-.33*math.cos(a)
            vs.append(cap(a,.005+(end-.005)*j/nr))
    for j in range(nr):
        for i in range(nt):a=j*nt+i;b=j*nt+(i+1)%nt;fs.append((a,b,b+nt,a+nt))
    mesh('Short dark brown hair cap',vs,fs,hair)
    rng=random.Random(412)
    for i in range(22):
        x=-.174+.348*i/21;tip=.096+.035*abs(x)/.174+rng.uniform(-.014,.011)
        width=rng.uniform(.021,.032);sweep=rng.uniform(-.010,.012)
        vs=[];fs=[];steps=25;across=8
        for j in range(steps+1):
            t=j/steps;px=x*(.73+.27*t)+sweep*math.sin(math.pi*t)
            py=-.068-.112*math.sin(t*math.pi/2);pz=.277+(tip-.277)*t
            w=width*(.4+.7*math.sin(math.pi*t))*(1-t**8)**.55
            for k in range(across+1):
                q=-1+2*k/across
                vs.append((px+q*w/2,py-.0055*math.sqrt(max(0,1-q*q))-.002*math.sin(t*math.pi),pz+.003*q*q))
        for j in range(steps):
            for k in range(across):a=j*(across+1)+k;fs.append((a,a+1,a+across+2,a+across+1))
        mesh('Tapered fringe lock',vs,fs,hair_light if i%7==0 else hair)
    for i in range(75):
        a=rng.uniform(-math.pi,math.pi);end=1.55-.33*math.cos(a)
        points=[]
        for j in range(9):
            p=.12+(end-.17)*j/8;co=Vector(cap(a+.025*math.sin(p*3),p))
            co+=Vector((co.x,co.y-.023,co.z-.025)).normalized()*.0008;points.append(co)
        line('Fine hair fibre',points,.00036,hair_light if i%5==0 else hair,[.3,.7,1,1,1,.9,.8,.5,.1])
    head['reference']='Refined stylized likeness: dark-brown fringe, oval face, inset brown eyes, integrated nose and thin natural lips.'
    return made


def replace_all():
    roots=['Narrator seated','Narrator at computer','Narrator on stage']
    for sector,name in enumerate(roots):
        head=bpy.data.objects[name+' head']
        old=[]
        def collect(parent):
            for child in parent.children:
                collect(child);old.append(child)
        collect(head)
        bpy.data.batch_remove(old)
        create_portrait(head,sector)
    for obj in list(bpy.data.objects):
        if obj.get('shirt_print'):bpy.data.objects.remove(obj,do_unlink=True)
    for image in list(bpy.data.images):
        if image.name.startswith('Adrian | shirt') and image.users==0:bpy.data.images.remove(image)
