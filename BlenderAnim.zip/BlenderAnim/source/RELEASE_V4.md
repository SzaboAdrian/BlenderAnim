# Fourth edition: rain, refined portrait, plain shirt and a slow stage greeting

The complete movie is 2,712 frames at 24 fps: **113 seconds**. All eleven shots are rendered from the updated Blender scene. The delivery includes the complete movie, standalone editable project and soundtrack.

The male character now has a continuous sculpted face including the nose, shallow integrated lip surfaces, inset almond eyes with occasional blinks, tapered eyebrows and very dark brown hair. The former spherical nose pieces, projecting eyeballs and tubular lips are replaced. All six shirt-print planes are removed. Hair remains brown rather than pure black. Static facial geometry and hair curves are bundled to reduce draw calls without losing their detail.

Rain falls throughout the bus-stop sequence, starting in the establishing shot. The native shader clips it below the shelter canopy and the ground. Shallow puddles, subdued overcast illumination and synthesized rain ambience complete the weather. The frosted canopy is opaque to avoid noisy refraction. The final studio camera keeps the face clear of the monitor and presents a gentler three-quarter angle.

The stage shot is extended by four seconds. The wrist follows an outward arc while the arm rises, with a stable IK bend direction and compatible quaternion rotations. A slim palm and rounded fingers clarify the greeting. The audience keeps moving during the gesture. Timing at 24 fps:

| Action | Frames |
| --- | --- |
| Reach the stage centre and finish turning | by 2065 |
| Raise the hand smoothly | 2065–2101 |
| Slow greeting | 2101–2173 |
| Lower the hand | 2173–2209 |
| Brief rest before departure | 2209–2232 |
| Preserved 20-second drone move | 2233–2712 |
| Closing dedication starts appearing | 2365 |

The exact dedication is unchanged: `Maybe in another life, there will be an opportunity, to be more than a dreamer, Adrian`. The blue/lavender grade and packed DejaVu Serif Italic title remain in the compositor. The soundtrack is extended by a matching four-second instrumental phrase; earlier dialogue subtitles, typing cues and transitions retain their synchronization.

## Using the project

Open `output/bus_stop_to_stage.blend` in Blender 4.3 or newer. Keep `final_mix_v4.wav` next to it. The title is packed, and all scene geometry is procedural and stored in the file. The final project needs no external models or add-ons. Use Render → Render Animation for a normal 1280 × 720, 24 fps, 32-sample EEVEE render.

The supplied MP4 is 960 × 540, H.264/AAC, 24 fps. Native full-frame source renders use 12 temporal samples per second and per-shot optical interpolation to 24 fps, preserving hard cuts. Most source frames use 4 EEVEE samples; the two male close-ups use 8. No film grain is added. This is a stylized 3D film.

## Source scripts

- `portrait_v4.py`: the updated face and hair geometry.
- `build_v4.py`: the production upgrade from the previous edition, including timing, weather, gesture and final scene settings. It imports `animation_v2.py` and `geometry_v2.py` for shared IK and geometry helpers. This one-time upgrade expects the previous edition as input; ordinary edits should start from the supplied final project.
- `soundtrack_v4.py`: extends the preceding 109-second mix and synthesizes rain. The previous mix is a production input, not required by the finished project.
- `render_v4.py`: renders the supplied final project into `output/final_frames_v4/`. Two processes can share the same directory through atomic frame claims. The source PNG cache is omitted from the download.
- `assemble_v4.py`: assembles all eleven shots, interpolates within each shot, adds the complete soundtrack and checks frame count, duration and decoding. FFmpeg and FFprobe are required for this optional encoding step.
- `check_v4.py`: checks actual arm endpoints and quaternion continuity, hand-lowering timing, the camera hold, plain shirts, weather visibility and portable resources.

Verification records are included with the sources. The earlier three-second freeze is replaced by the requested greeting and short rest. The drone's camera path and duration are preserved, shifted four seconds later.
