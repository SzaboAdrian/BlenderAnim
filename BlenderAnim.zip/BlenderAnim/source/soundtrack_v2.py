"""Original synthesized ambience, musical cues and effects; no third-party recordings."""
from pathlib import Path
import numpy as np, wave
SR=32000;DURATION=109
rng=np.random.default_rng(109);mix=np.zeros((SR*DURATION,2),np.float32)
def add(at,sound,gain=1,pan=0):
    start=int(at*SR);sound=np.asarray(sound,np.float32);end=min(len(mix),start+len(sound))
    if end<=start:return
    x=sound[:end-start]*gain
    mix[start:end,0]+=x*np.sqrt((1-pan)/2);mix[start:end,1]+=x*np.sqrt((1+pan)/2)
def note(freq,duration,decay=2):
    t=np.arange(int(duration*SR))/SR
    env=(1-np.exp(-t*120))*np.exp(-t*decay)*np.minimum(1,(duration-t)*15)
    return env*(np.sin(2*np.pi*freq*t)+.22*np.sin(2*np.pi*freq*2*t)+.07*np.sin(2*np.pi*freq*3*t))
# Sparse piano-like motif leaves room for the dialogue.
for at,f in [(2,220),(6,261.63),(10,329.63),(15,220),(21,196),(29,164.81),(42,220),(46,261.63),(48,329.63)]:add(at,note(f,4,.8),.06,-.1)
# Breeze and birds around the stop.
noise=rng.normal(0,1,SR*52);wind=np.convolve(noise,np.ones(220)/220,'same')
add(0,wind,.16)
for at in [3,8,11,17,24,30,46]:
    t=np.arange(int(.7*SR))/SR;x=np.sin(2*np.pi*(1700*t+350*np.sin(t*14)/14))*np.sin(np.pi*t/.7)**3
    add(at,x,.012,float(rng.uniform(-.7,.7)))
# Bus approaches, idles, then pulls away during the widened boarding shot.
t=np.arange(SR*18)/SR
engine=(np.sin(2*np.pi*(58*t+1.4*t*t))+.3*np.sin(2*np.pi*116*t))
env=np.minimum(t/3,1)*np.minimum((18-t)/3,1)
add(31,engine*env,.045,.35)
for at in [35,42]:
    t=np.arange(int(.8*SR))/SR;add(at,rng.normal(0,1,len(t))*np.exp(-t*7),.025,.3)
# Idea chime.
for i,f in enumerate([659.25,987.77,1318.5]):add(47.55+i*.10,note(f,1.6,2.3),.10,.1)
# Each space-bar press gets one short phrase; presses are 4.5 seconds apart.
presses=[1273,1381,1489,1597,1705,1813]
for frame in presses:
    at=(frame-1)/24+.30
    add(at,rng.normal(0,1,int(.035*SR))*np.linspace(1,0,int(.035*SR)),.045)
    for k in range(4):
        t=np.arange(int(.28*SR))/SR;phase=2*np.pi*(48*t+34*(1-np.exp(-t*25))/25)
        add(at+k*.25,np.sin(phase)*np.exp(-t*18),.16)
        add(at+k*.25,note([220,261.63,329.63,392][k],.45,7),.055,.12)
# A restrained instrumental beat opens up on stage.
for at in np.arange(78.5,107,.5):
    t=np.arange(int(.3*SR))/SR;add(at,np.sin(2*np.pi*(50*t+1.2*(1-np.exp(-t*35))))*np.exp(-t*15),.12)
for i,at in enumerate(np.arange(78.5,106.8,.25)):
    add(at,note([220,261.63,329.63,440,392,329.63,261.63,196][i%8],.7,5),.04,(-.3 if i%2 else .3))
# Soft cheering texture and whistles, kept below the music.
t=np.arange(SR*32)/SR;noise=rng.normal(0,1,len(t));crowd=np.convolve(noise,np.ones(14)/14,'same')
add(77,crowd*(.6+.4*np.sin(t*1.4)**2),.065)
for at in [79,84,89,95]:
    t=np.arange(int(1.3*SR))/SR;add(at,np.sin(2*np.pi*(1100*t+60*t*t))*np.sin(np.pi*t/1.3)**2,.008,-.4)
# Match the two editorial black transitions and final fade.
for a,b,c in [(50,52,53),(75.5,77,78.5)]:
    for i in range(int(a*SR),int(c*SR)):
        tt=i/SR;factor=(b-tt)/(b-a) if tt<b else (tt-b)/(c-b);mix[i]*=max(0,min(1,factor))
fade=np.minimum(1,np.arange(len(mix))/(SR*.8))*np.minimum(1,(len(mix)-np.arange(len(mix)))/(SR*2))
mix*=fade[:,None];peak=np.max(np.abs(mix));mix*=.72/peak
out=Path(__file__).resolve().parent/'output'/'final_mix.wav'
with wave.open(str(out),'wb') as w:w.setparams((2,2,SR,0,'NONE','not compressed'));w.writeframes((mix*32767).astype('<i2').tobytes())
print('SOUNDTRACK',out,DURATION,'seconds',float(peak))
