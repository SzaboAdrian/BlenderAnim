"""Reuse unaffected native frames and encoded shots; rerender changed actions."""
from pathlib import Path
import json
import os

BASE=Path(__file__).resolve().parent
if BASE.name=='source':BASE=BASE.parent
OUT=BASE/'output'
changes=json.loads((OUT/'single_tap_validation_v5.json').read_text())
changed=set(changes['render_frames'])
destination=OUT/'final_frames_v5';destination.mkdir(exist_ok=True)
for frame in range(1,2713,2):
    source=OUT/'final_frames_v4'/f'{frame:05d}.png'
    assert source.is_file(),source
    target=destination/source.name
    if frame not in changed and not target.exists():os.link(source,target)
segments=OUT/'encoded_v5';segments.mkdir(exist_ok=True)
for shot in [1,2,3,4,5,6,7,10,11]:
    source=OUT/'encoded_v4'/f'{shot:02d}.mp4';assert source.is_file()
    target=segments/source.name
    if not target.exists():os.link(source,target)
print('V5_INCREMENTAL_RENDER_READY',len(changed),'native frames to refresh, 9 complete shots reused',flush=True)
