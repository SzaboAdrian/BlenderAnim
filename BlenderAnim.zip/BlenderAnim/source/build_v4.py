"""Rainy opening, refined portrait, plain shirt and a slow greeting on stage."""
from pathlib import Path
import math
import random
import sys
import bpy
from mathutils import Vector, Euler

BASE=Path(__file__).resolve().parent
if BASE.name=='source':BASE=BASE.parent
sys.path.insert(0,str(Path(__file__).resolve().parent))
from portrait_v4 import replace_all,mat
from geometry_v2 import mesh,sphere
from animation_v2 import ik,ease

END=2712
DRONE=2233


def extend_stage(scene):
    for action in bpy.data.actions:
        for fc in action.fcurves:
            for key in fc.keyframe_points:
                if key.co.x>=2137:
                    key.co.x+=96;key.handle_left.x+=96;key.handle_right.x+=96
    for marker in scene.timeline_markers:
        if marker.frame>=2137:marker.frame+=96
    scene.frame_end=END


def rain(scene):
    # A frosted opaque canopy avoids stochastic refraction speckles in the rain.
    roof=bpy.data.materials.get('Shelter polycarbonate')
    if roof:
        shader=roof.node_tree.nodes.get('Principled BSDF')
        shader.inputs['Transmission Weight'].default_value=0
        shader.inputs['Roughness'].default_value=.58
    material=bpy.data.materials.new('V4 silver rain, clipped beneath shelter')
    material.use_nodes=True;nodes=material.node_tree.nodes;nodes.clear();links=material.node_tree.links
    geo=nodes.new('ShaderNodeNewGeometry');sep=nodes.new('ShaderNodeSeparateXYZ');links.new(geo.outputs['Position'],sep.inputs[0])
    def op(operation,*values):
        n=nodes.new('ShaderNodeMath');n.operation=operation
        for i,value in enumerate(values):
            if isinstance(value,(int,float)):n.inputs[i].default_value=value
            else:links.new(value,n.inputs[i])
        return n.outputs[0]
    x,y,z=[sep.outputs[c] for c in 'XYZ']
    covered=op('MULTIPLY',op('LESS_THAN',op('ABSOLUTE',x),2.56),op('GREATER_THAN',y,-.92))
    covered=op('MULTIPLY',covered,op('LESS_THAN',y,1.43))
    covered=op('MULTIPLY',covered,op('LESS_THAN',z,3.23))
    visible=op('MULTIPLY',op('GREATER_THAN',z,.015),op('LESS_THAN',z,11))
    visible=op('MULTIPLY',visible,op('SUBTRACT',1,covered))
    emission=nodes.new('ShaderNodeEmission');emission.inputs[0].default_value=(.43,.53,.67,1);emission.inputs[1].default_value=.55
    transparent=nodes.new('ShaderNodeBsdfTransparent');mix=nodes.new('ShaderNodeMixShader');out=nodes.new('ShaderNodeOutputMaterial')
    links.new(visible,mix.inputs[0]);links.new(transparent.outputs[0],mix.inputs[1]);links.new(emission.outputs[0],mix.inputs[2]);links.new(mix.outputs[0],out.inputs[0])
    rng=random.Random(907);vertices=[];faces=[]
    for i in range(1400):
        p=Vector((rng.uniform(-14,14),rng.uniform(-8,17),rng.uniform(0,10)))
        length=rng.uniform(.075,.19);width=rng.uniform(.0017,.0031)
        end=p+Vector((.13*length,.04*length,-length));index=len(vertices)
        for normal in [Vector((width,0,0)),Vector((0,width,0))]:
            vertices.extend([p-normal,p+normal,end+normal*.35,end-normal*.35])
        faces.extend([(index,index+1,index+2,index+3),(index+4,index+5,index+6,index+7)])
    data=bpy.data.meshes.new('V4 rain streak tile');data.from_pydata(vertices,[],faces);data.materials.append(material);data.update()
    for layer in [-1,0,1,2]:
        obj=bpy.data.objects.new('V4 falling rain '+str(layer),data);scene.collection.objects.link(obj)
        obj['render_sector']=0;obj['weather_v4']=True;obj.visible_shadow=False
        driver=obj.driver_add('location',2).driver;driver.expression=f'{layer*10} - (((frame-1)*0.285) % 10)'
    wet=mat('V4 rain-darkened paving',(.095,.12,.145),.23,.4)
    wet.node_tree.nodes['Principled BSDF'].inputs['Metallic'].default_value=.12
    scenery=scene.objects['Merged scenery 0']
    for i,m in enumerate(scenery.data.materials):
        if m and m.name=='Pavement':scenery.data.materials[i]=wet
    puddle=mat('V4 puddle reflections',(.046,.066,.082),.12,.5)
    nodes=puddle.node_tree.nodes;links=puddle.node_tree.links;p=nodes.get('Principled BSDF')
    p.inputs['Metallic'].default_value=.23
    wave=nodes.new('ShaderNodeTexWave');wave.wave_type='RINGS';wave.rings_direction='Z';wave.inputs['Scale'].default_value=11;wave.inputs['Distortion'].default_value=1.7
    wave.inputs['Phase Offset'].driver_add('default_value').driver.expression='frame * 0.13'
    bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.22;bump.inputs['Distance'].default_value=.004
    links.new(wave.outputs['Color'],bump.inputs['Height']);links.new(bump.outputs['Normal'],p.inputs['Normal'])
    for i in range(13):
        x=rng.uniform(-7,7);y=rng.uniform(-1.85,-1.10);rx=rng.uniform(.18,.57);ry=rng.uniform(.07,.18)
        vertices=[(x,y,.007)]
        for k in range(48):
            a=math.tau*k/48;r=1+.1*math.sin(a*3+i)+.06*math.cos(a*7)
            vertices.append((x+rx*r*math.cos(a),y+ry*r*math.sin(a),.006))
        obj=mesh('V4 shallow rain puddle',vertices,[(0,k+1,(k+1)%48+1) for k in range(48)],puddle)
        obj['render_sector']=0;obj['weather_v4']=True
    # Overcast illumination affects the stop only; studio and concert keep their grade.
    sun=bpy.data.lights['Golden hour sun']
    for frame in (1,1248):sun.energy=.28;sun.keyframe_insert('energy',frame=frame)
    for frame,angle in [(1,.55),(1248,.55),(1249,.18),(END,.18)]:
        sun.angle=angle;sun.keyframe_insert('angle',frame=frame)
    for fc in sun.animation_data.action.fcurves:
        for key in fc.keyframe_points:key.interpolation='CONSTANT'
    scene.objects['Stop softbox'].data.color=(.73,.81,1)
    scene.objects['Stop softbox'].data.energy=460
    scene.objects['Evening sky fill'].data.energy=1200
    bg=scene.world.node_tree.nodes['Background']
    for frame in (1,1248):
        bg.inputs[0].default_value=(.16,.22,.31,1);bg.inputs[0].keyframe_insert('default_value',frame=frame)


def compact_portraits(scene):
    """Reduce draw calls without changing geometry or the animated eye pivots."""
    def merge_meshes(parent):
        objects=[o for o in parent.children if o.type=='MESH' and not o.modifiers and not o.animation_data]
        if not objects:return
        vertices=[];faces=[];indices=[];materials=[];mapping={}
        for obj in objects:
            offset=len(vertices);vertices.extend(obj.matrix_basis@v.co for v in obj.data.vertices)
            slots=[]
            for m in obj.data.materials:
                if m.name not in mapping:mapping[m.name]=len(materials);materials.append(m)
                slots.append(mapping[m.name])
            for p in obj.data.polygons:
                faces.append(tuple(offset+i for i in p.vertices));indices.append(slots[p.material_index])
        data=bpy.data.meshes.new(parent.name+' refined surfaces');data.from_pydata(vertices,[],faces);data.update()
        for m in materials:data.materials.append(m)
        for p,i in zip(data.polygons,indices):p.material_index=i;p.use_smooth=True
        obj=bpy.data.objects.new(data.name,data);scene.collection.objects.link(obj);obj.parent=parent
        obj['render_sector']=objects[0]['render_sector'];obj['portrait_v4']=True
        bpy.data.batch_remove(objects)
    for name in ['Narrator seated','Narrator at computer','Narrator on stage']:
        head=scene.objects[name+' head']
        for child in list(head.children):
            if child.type=='EMPTY':merge_meshes(child)
        merge_meshes(head)
        fibres=[o for o in head.children if o.type=='CURVE' and 'Fine hair fibre' in o.name]
        if fibres:
            data=bpy.data.curves.new(head.name+' bundled fine hair','CURVE')
            data.dimensions='3D';data.bevel_depth=.00036;data.bevel_resolution=2
            materials=[]
            for obj in fibres:
                material=obj.data.materials[0]
                if material not in materials:materials.append(material);data.materials.append(material)
                for old in obj.data.splines:
                    spline=data.splines.new('BEZIER');spline.bezier_points.add(len(old.bezier_points)-1)
                    spline.material_index=materials.index(material)
                    for p,q in zip(spline.bezier_points,old.bezier_points):
                        p.co=q.co;p.radius=q.radius;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
            obj=bpy.data.objects.new(data.name,data);scene.collection.objects.link(obj);obj.parent=head
            obj['render_sector']=fibres[0]['render_sector'];obj['portrait_v4']=True
            bpy.data.batch_remove(fibres)


def gesture(scene):
    root=scene.objects['Narrator on stage']
    skin=bpy.data.materials['V4 natural warm skin']
    def remove_after(obj,start):
        if obj.animation_data and obj.animation_data.action:
            for fc in obj.animation_data.action.fcurves:
                for i in range(len(fc.keyframe_points)-1,-1,-1):
                    if fc.keyframe_points[i].co.x>=start:fc.keyframe_points.remove(fc.keyframe_points[i],fast=True)
                fc.update()
    def bone(obj,a,b,frame):
        obj.location=(a+b)/2;obj.keyframe_insert('location',frame=frame)
        # Transport the preceding bone frame instead of choosing a new global
        # up axis, which can twist a forearm as it passes a horizontal pose.
        obj.rotation_mode='QUATERNION';previous=obj.rotation_quaternion.normalized()
        old_axis=previous@Vector((0,0,1));new_axis=(b-a).normalized()
        q=old_axis.rotation_difference(new_axis)@previous;q.normalize();q.make_compatible(previous)
        obj.rotation_quaternion=q;obj.keyframe_insert('rotation_quaternion',frame=frame)
    scene.frame_set(2064)
    for side,suffix in [(-1,''),(1,'.001')]:
        upper=scene.objects['Narrator on stage upper arm'+suffix]
        lower=scene.objects['Narrator on stage forearm'+suffix]
        elbow_obj=scene.objects['Narrator on stage elbow'+suffix]
        hand=scene.objects['Narrator on stage hand'+suffix]
        initial=hand.location.copy()
        for obj in [upper,lower,elbow_obj,hand]:remove_after(obj,2065)
        for fc in list(hand.animation_data.action.fcurves):
            if fc.data_path=='rotation_euler':hand.animation_data.action.fcurves.remove(fc)
        hand.rotation_mode='QUATERNION';hand.rotation_quaternion=Euler((0,math.pi,0)).to_quaternion()
        hand.keyframe_insert('rotation_quaternion',frame=1);hand.keyframe_insert('rotation_quaternion',frame=2064)
        # A slim palm and separate rounded fingers make the greeting readable.
        for v in hand.data.vertices:v.co.x*=.9;v.co.y*=.36;v.co.z*=.72
        for i,x in enumerate([-.026,-.0085,.009,.026]):
            finger=sphere('V4 stage finger',(x,0,.056),(.009,.0105,[.029,.036,.034,.025][i]),skin,hand,n=12,r=10)
            finger['render_sector']=2;finger['gesture_v4']=True
        thumb=sphere('V4 stage thumb',(side*.043,-.001,.010),(.011,.011,.025),skin,hand,n=12,r=10)
        thumb.rotation_euler.y=side*.48;thumb['render_sector']=2;thumb['gesture_v4']=True
        for frame in range(2065,END+1):
            breath=.002*math.sin(frame*math.tau/108)
            shoulder=Vector((side*.28,-.03,1.30+breath))
            rest=Vector((side*.31,-.05,.735+breath))
            wave_phase=math.tau*(frame-2101)/48
            wave_window=ease((frame-2101)/10)*(1-ease((frame-2163)/10))
            raised=ease((frame-2065)/36)*(1-ease((frame-2173)/36)) if side>0 else 0
            target=initial.lerp(rest,ease((frame-2065)/36))
            high=Vector((.40+.040*math.sin(wave_phase)*wave_window,-.065,1.855+breath))
            target=target.lerp(high,raised)
            # An outward arc keeps the wrist away from the shoulder while
            # raising/lowering, avoiding a tightly folded, flipping IK pose.
            if side>0:target.x+=.29*math.sin(math.pi*raised)
            new_pole=Vector((.25,-1,-.15) if side>0 else (side,-.16,-.15))
            pole=Vector((side,-.15,-.5)).lerp(new_pole,ease((frame-2065)/24))
            elbow,wrist,_=ik(shoulder,target,.31,.32,pole)
            bone(upper,shoulder,elbow,frame);bone(lower,elbow,wrist,frame)
            elbow_obj.location=elbow;elbow_obj.keyframe_insert('location',frame=frame)
            hand.location=wrist;hand.keyframe_insert('location',frame=frame)
            angle=math.pi*(1-raised)+.24*math.sin(wave_phase)*wave_window*raised
            q=Euler((0,angle,0)).to_quaternion();q.make_compatible(hand.rotation_quaternion)
            hand.rotation_quaternion=q;hand.keyframe_insert('rotation_quaternion',frame=frame)
        for obj in [upper,lower,elbow_obj,hand]:
            for fc in obj.animation_data.action.fcurves:
                for key in fc.keyframe_points:key.interpolation='LINEAR'
    # Keep the crowd alive while Adrian acknowledges them.
    data=scene.objects['Festival audience with cheering poses'].data.shape_keys
    data.animation_data_clear()
    for name,phase in [('Wave A',0),('Wave B',1.9)]:
        key=data.key_blocks[name]
        frames=sorted(set(range(1849,DRONE,6))|{DRONE-1}|set(range(DRONE,END+1,6))|{END})
        for frame in frames:
            original=frame-96 if frame>=DRONE else frame
            key.value=.5+.48*math.sin((original-1849)*.035+phase);key.keyframe_insert('value',frame=frame)
    for fc in data.animation_data.action.fcurves:
        for key in fc.keyframe_points:key.interpolation='LINEAR'
    scene['stage_gesture']='Arrive and turn by 2065; raise hand 2065–2101; slow greeting 2101–2173; lower 2173–2209; drone starts 2233.'


def finish(scene):
    camera=scene.objects['09 Studio face push'];camera.animation_data_clear();camera.data.lens=50
    for frame,loc in [(1705,(41.5,-.05,1.94)),(1848,(40.68,-.04,1.81))]:
        camera.location=loc;camera.rotation_euler=(Vector((40,-1.05,1.61))-camera.location).to_track_quat('-Z','Y').to_euler()
        camera.keyframe_insert('location',frame=frame);camera.keyframe_insert('rotation_euler',frame=frame)
    for fc in camera.animation_data.action.fcurves:
        for key in fc.keyframe_points:key.interpolation='BEZIER';key.handle_left_type='AUTO_CLAMPED';key.handle_right_type='AUTO_CLAMPED'
    for obj in scene.objects:
        if 'render_sector' not in obj:continue
        sector=obj['render_sector']
        for frame,active in [(1,0),(1248,0),(1249,1),(1848,1),(1849,2),(END,2)]:
            obj.hide_render=sector!=active;obj.keyframe_insert('hide_render',frame=frame)
        for fc in obj.animation_data.action.fcurves:
            if fc.data_path=='hide_render':
                for key in fc.keyframe_points:key.interpolation='CONSTANT'
    if scene.sequence_editor:
        for seq in list(scene.sequence_editor.sequences):scene.sequence_editor.sequences.remove(seq)
    scene.sequence_editor_create().sequences.new_sound('Rain, music and festival ambience',str(BASE/'output/final_mix_v4.wav'),channel=1,frame_start=1)
    for sound in bpy.data.sounds:
        if Path(sound.filepath).name=='final_mix_v4.wav':sound.filepath='//final_mix_v4.wav'
    for sound in list(bpy.data.sounds):
        if sound.users==0:bpy.data.sounds.remove(sound)
    scene.frame_start=1;scene.frame_end=END;scene.frame_set(1)
    scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.render.resolution_percentage=100
    scene.eevee.taa_render_samples=32
    scene.render.image_settings.file_format='FFMPEG';scene.render.ffmpeg.format='MPEG4';scene.render.ffmpeg.codec='H264';scene.render.ffmpeg.audio_codec='AAC'
    scene.render.filepath='//BlenderAnim_final.mp4'
    scene['edition']=4;scene['finishing_notes']='Plain black shirt. Refined continuous face and dark brown hair. Rain at the stop. Slow stage wave before the preserved 20-second drone departure.'
    text=bpy.data.texts.get('READ ME — Melancholy edition')
    if text:text.clear();text.write('Edition 4 — 113 seconds, 24 fps.\nRain, refined portrait, plain shirt, slow wave.\nDrone begins at frame 2233 after the hand is lowered.\nKeep final_mix_v4.wav next to this project.\nPacked closing words and melancholy grading are in the compositor.\n\n'+scene['closing_quote'])
    bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'output/film_render_v4.blend'))


if __name__=='__main__':
    scene=bpy.context.scene
    extend_stage(scene)
    replace_all()
    compact_portraits(scene)
    rain(scene)
    gesture(scene)
    finish(scene)
    print('V4_PROJECT_READY',flush=True)
