"""Render the changed studio push, or selected native-project proof frames."""
from pathlib import Path
import sys
import time
import bpy

BASE = Path(__file__).resolve().parent
if BASE.name == 'source':
    BASE = BASE.parent
scene = bpy.context.scene
scene.render.engine = 'BLENDER_EEVEE_NEXT'
scene.eevee.taa_render_samples = 4
scene.render.resolution_x = 960
scene.render.resolution_y = 540
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.image_settings.color_mode = 'RGB'
scene.render.image_settings.compression = 15
args = sys.argv[sys.argv.index('--') + 1:] if '--' in sys.argv else []
proof = bool(args and args[0] == 'proof')
frames = [int(f) for f in args[1:]] if proof else range(1705, 1849, 2)
destination = BASE / 'output' / ('v3_proofs' if proof else 'melancholy_frames')
destination.mkdir(exist_ok=True)
for f in frames:
    path = destination / f'{f:05d}.png'
    if path.exists():
        continue
    scene.frame_set(f)
    scene.render.filepath = str(path)
    start = time.time()
    bpy.ops.render.render(write_still=True)
    print('V3_NATIVE_FRAME', f, round(time.time() - start, 3), flush=True)
