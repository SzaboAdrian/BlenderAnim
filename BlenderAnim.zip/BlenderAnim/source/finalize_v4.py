"""Remove obsolete print assets and save a portable, opening-frame project."""
from pathlib import Path
import bpy

scene=bpy.context.scene
for material in list(bpy.data.materials):
    if material.name.startswith('Adrian | soft silver') and material.users==0:
        bpy.data.materials.remove(material)
for image in list(bpy.data.images):
    if image.name.startswith('Adrian | shirt') and image.users==0:
        bpy.data.images.remove(image)
for image in bpy.data.images:
    if image.packed_file:image.filepath='//assets_v3/'+Path(image.filepath).name
for sound in list(bpy.data.sounds):
    if sound.users==0:bpy.data.sounds.remove(sound)
    elif Path(sound.filepath).name=='final_mix_v4.wav':sound.filepath='//final_mix_v4.wav'
marker=next(m for m in scene.timeline_markers if m.frame==1849)
marker.name='10 Stage arrival and greeting';marker.camera.name=marker.name
scene.frame_set(1)
scene.render.resolution_x=1280;scene.render.resolution_y=720;scene.render.resolution_percentage=100
scene.eevee.taa_render_samples=32;scene.render.use_border=False;scene.render.use_crop_to_border=False
scene.render.image_settings.file_format='FFMPEG';scene.render.ffmpeg.format='MPEG4';scene.render.ffmpeg.codec='H264'
scene.render.ffmpeg.audio_codec='AAC';scene.render.ffmpeg.audio_bitrate=192
scene.render.filepath='//BlenderAnim_final.mp4'
assert scene.frame_end==2712 and not any(o.get('shirt_print') for o in scene.objects)
bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
print('V4_PORTABLE_PROJECT_FINALIZED',flush=True)
