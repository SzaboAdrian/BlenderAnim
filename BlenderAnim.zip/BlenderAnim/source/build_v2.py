import bpy,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
from animation_v2 import retime,apply
from polish_v2 import apply as polish
s=bpy.context.scene
if s.get('film_version'):raise RuntimeError('Build from original bus_stop_to_stage.blend, not the v2 output')
retime(s);apply(s);polish(s)
# Relative paths make the project portable after download.
for sound in bpy.data.sounds:
    sound.filepath='//'+Path(sound.filepath).name
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'output/bus_stop_to_stage_v2.blend'))
print('V2_SAVED',len(s.objects),s.frame_end,flush=True)
