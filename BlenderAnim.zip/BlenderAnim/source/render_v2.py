import bpy,sys,time,json,os
from pathlib import Path
s=bpy.context.scene
BASE=Path(__file__).resolve().parent
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
mode=args[0] if args else 'checks'
s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=4
s.render.resolution_x=960;s.render.resolution_y=540;s.render.resolution_percentage=100
s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.render.image_settings.compression=15
sector=None

def select(f):
    global sector
    wanted=0 if f<1249 else 1 if f<1849 else 2
    if wanted!=sector:
        for o in s.objects:
            if 'render_sector' in o:o.hide_render=o['render_sector']!=wanted
        sector=wanted
    s.frame_set(f)

if mode=='checks':
    for f,name in [(380,'walk_v2'),(1190,'idea_v2'),(1500,'studio_v2'),(1940,'stage_v2'),(2450,'drone_v2'),(2452,'drone_v2_next')]:
        select(f);s.render.filepath=str(BASE/'output'/f'{name}.png');t=time.time();bpy.ops.render.render(write_still=True);print('SHOT_SECONDS',name,round(time.time()-t,2),flush=True)
else:
    start=int(args[1]);end=int(args[2]);step=int(args[3]) if len(args)>3 else 1
    folder=BASE/'output'/'final_frames';folder.mkdir(exist_ok=True)
    pending=folder/'.pending';pending.mkdir(exist_ok=True)
    for f in range(start,end+1,step):
        output=folder/f'{f:05d}.png'
        if output.exists():continue
        lock=pending/f'{f:05d}.lock'
        try:
            fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY);os.write(fd,str(os.getpid()).encode());os.close(fd)
        except FileExistsError:continue
        try:
            if output.exists():continue
            select(f);temporary=pending/f'{f:05d}-{os.getpid()}.png';s.render.filepath=str(temporary)
            t=time.time();bpy.ops.render.render(write_still=True);temporary.replace(output)
            print('FRAME_DONE',f,round(time.time()-t,3),flush=True)
        finally:
            lock.unlink(missing_ok=True)
