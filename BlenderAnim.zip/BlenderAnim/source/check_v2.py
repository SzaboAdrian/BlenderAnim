import bpy,sys,math,json
from pathlib import Path
from mathutils import Vector
from bpy_extras.object_utils import world_to_camera_view
sys.path.insert(0,str(Path(__file__).resolve().parent))
from animation_v2 import TAPS
s=bpy.context.scene
assert not any(o.type=='FONT' and 'BUS' in o.data.body for o in s.objects)
assert s.frame_end==2616 and s.render.fps==24
assert all(b-a==108 for a,b in zip(TAPS,TAPS[1:]))
# A rigid segment has its ends on both its neighbouring joints.
for name in ['Narrator seated','Woman standing','Narrator on stage']:
    root=s.objects[name];upper=sorted([o for o in root.children if ' upper leg' in o.name],key=lambda o:o.name);lower=sorted([o for o in root.children if ' lower leg' in o.name],key=lambda o:o.name)
    for f in [350,380,420] if name=='Narrator seated' else [865,910,975] if name=='Woman standing' else [1900,1975,2030]:
        s.frame_set(f)
        for u,l in zip(upper,lower):
            endpoint=u.matrix_world@Vector((0,0,.23));start=l.matrix_world@Vector((0,0,-.23));gap=(endpoint-start).length
            assert gap<.002,(name,f,gap)
            assert abs(u.scale.z-1)<1e-5 and abs(l.scale.z-1)<1e-5
s.frame_set(1190)
bulb=s.objects['Idea bulb'];top=bulb.matrix_world@Vector((0,0,.38));uv=world_to_camera_view(s,s.camera,top)
assert 0<uv.x<1 and 0<uv.y<1,tuple(uv)
for f in [1848,1849,2616]:
    s.frame_set(f);assert s.node_tree.nodes['Editorial fades'].inputs[2].default_value[0]<.001
s.frame_set(1885);assert s.node_tree.nodes['Editorial fades'].inputs[2].default_value[0]>.999
print('V2_CHECKS_PASS',json.dumps({'duration_seconds':109,'keyboard_interval':4.5,'leg_joint_gap':'<2 mm, including interpolated frames','bulb_in_camera':True,'fade_out_and_in':True}),flush=True)
