"""One keyboard click starts a continuing beat; the studio keeps its 25 seconds."""
from pathlib import Path
import json
import wave
import numpy as np

BASE=Path(__file__).resolve().parent
if BASE.name=='source':BASE=BASE.parent
OUT=BASE/'output'
with wave.open(str(OUT/'final_mix_v4.wav'),'rb') as stream:
    rate=stream.getframerate();assert stream.getnchannels()==2 and stream.getsampwidth()==2
    original=np.frombuffer(stream.readframes(stream.getnframes()),dtype='<i2').reshape(-1,2).copy()
assert len(original)==113*rate
start,end=52*rate,77*rate
studio=np.zeros((end-start,2),np.float32)
rng=np.random.default_rng(505)
click_at=1.30

def add(at,sound,gain,pan=0):
    first=round(at*rate);last=min(len(studio),first+len(sound))
    if last<=first:return
    sound=np.asarray(sound[:last-first],np.float32)*gain
    studio[first:last,0]+=sound*np.sqrt((1-pan)/2)
    studio[first:last,1]+=sound*np.sqrt((1+pan)/2)

def note(frequency,duration=.7):
    t=np.arange(round(duration*rate))/rate
    envelope=(1-np.exp(-t*120))*np.exp(-t*5)*np.minimum(1,(duration-t)*15)
    return envelope*(np.sin(2*np.pi*frequency*t)+.22*np.sin(4*np.pi*frequency*t)+.07*np.sin(6*np.pi*frequency*t))

# Exactly one keystroke; subsequent attacks belong to the playing music.
click=rng.normal(0,1,round(.035*rate))*np.linspace(1,0,round(.035*rate))
add(click_at,click,.045)
melody=[220,261.63,329.63,392,220,261.63,329.63,196]
for i,at in enumerate(np.arange(click_at,24.8,.25)):
    add(at,note(melody[i%len(melody)]),.045,.12)
    if i%2==0:
        t=np.arange(round(.28*rate))/rate
        phase=2*np.pi*(48*t+34*(1-np.exp(-t*25))/25)
        add(at,np.sin(phase)*np.exp(-t*18),.14)
time=np.arange(len(studio))/rate
studio*=np.clip((25-time)/1.5,0,1)[:,None]
reference=original[round(53.30*rate):round(54.50*rate)].astype(np.float32)/32767
first_phrase=studio[round(click_at*rate):round((click_at+1.2)*rate)]
gain=float(np.sqrt(np.mean(reference**2))/max(1e-9,np.sqrt(np.mean(first_phrase**2))))
studio*=gain
assert np.max(np.abs(studio))<.95
result=original.copy()
result[start:end]=np.rint(np.clip(studio,-1,1)*32767).astype('<i2')
assert np.array_equal(result[:start],original[:start]) and np.array_equal(result[end:],original[end:])
destination=OUT/'final_mix_v5.wav'
with wave.open(str(destination),'wb') as stream:
    stream.setparams((2,2,rate,0,'NONE','not compressed'));stream.writeframes(result.tobytes())
report={'seconds':113,'studio_start_seconds':52,'studio_end_seconds':77,
        'keyboard_click_seconds':[53.30],'click_count':1,'beat_continues_after_click':True,
        'outside_studio_pcm_identical':True,'studio_peak':float(np.max(np.abs(studio)))}
(OUT/'audio_validation_v5.json').write_text(json.dumps(report,indent=2))
print('V5_AUDIO_VERIFIED',json.dumps(report),flush=True)
