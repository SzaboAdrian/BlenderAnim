"""Set portable paths and the opening frame before packaging the final project."""
from pathlib import Path
import bpy

BASE = Path(__file__).resolve().parent
if BASE.name == 'source':
    BASE = BASE.parent
scene = bpy.context.scene
for image in bpy.data.images:
    if image.packed_file:
        image.filepath = '//assets_v3/' + Path(image.filepath).name
for sound in bpy.data.sounds:
    if Path(sound.filepath).name == 'final_mix.wav':
        sound.filepath = '//final_mix.wav'
scene.frame_set(1)
text = bpy.data.texts.get('READ ME — Melancholy edition') or bpy.data.texts.new('READ ME — Melancholy edition')
text.clear()
text.write('Full film: 109 seconds, 24 fps.\n\n'
           'Open the Compositing workspace for the blue-hour grade and closing words.\n'
           'The packed title appears during the final drone shot, from frame 2269.\n'
           'The shirt prints are children of each Narrator torso.\n'
           'Keep final_mix.wav next to this .blend.\n\n'
           'Closing text:\n' + scene['closing_quote'] + '\n')
assert scene.frame_end == 2616
assert len([o for o in scene.objects if o.get('shirt_print')]) == 6
assert all(i.packed_file for i in bpy.data.images if i.name.startswith(('Adrian |', 'Closing words |')))
bpy.ops.wm.save_as_mainfile(filepath=str(BASE / 'output' / 'film_render_v3.blend'))
print('V3_PORTABLE_PROJECT_SAVED', flush=True)
