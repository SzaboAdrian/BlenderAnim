"""Merge static scenery and bake the crowd into shape keys to keep full-film renders tractable."""
import bpy,math,sys,random
from pathlib import Path
from mathutils import Matrix,Vector
sys.path.insert(0,str(Path(__file__).resolve().parent))
from geometry_v2 import material
s=bpy.context.scene;s.frame_set(1930);graph=bpy.context.evaluated_depsgraph_get()

def merge(objects,name,parent=None):
    vertices=[];faces=[];indices=[];smooth_flags=[];materials=[];mapping={}
    for o in objects:
        d=o.data
        if not d:continue
        matrix=o.matrix_basis if parent else o.matrix_world
        offset=len(vertices);vertices.extend([matrix@v.co for v in d.vertices])
        slots=[]
        for m in d.materials:
            if m is None:continue
            if m.name not in mapping:mapping[m.name]=len(materials);materials.append(m)
            slots.append(mapping[m.name])
        for p in d.polygons:faces.append(tuple(offset+i for i in p.vertices));indices.append(slots[p.material_index] if slots else 0);smooth_flags.append(p.use_smooth)

    d=bpy.data.meshes.new(name);d.from_pydata(vertices,[],faces);d.update()
    for m in materials:d.materials.append(m)
    for p,i,sm in zip(d.polygons,indices,smooth_flags):p.material_index=i;p.use_smooth=sm
    o=bpy.data.objects.new(name,d);s.collection.objects.link(o);o.parent=parent
    bpy.data.batch_remove(objects)
    return o

# Head local geometry remains attached to its fully animated pivot.
for h in [o for o in s.objects if o.type=='EMPTY' and ' head' in o.name and (o.name.startswith('Narrator') or o.name.startswith('Woman'))]:
    children=[c for c in h.children if c.type=='MESH' and not c.modifiers]
    if children:merge(children,h.name+' unified geometry',h)
print('HEADS_MERGED',flush=True)
# Bake the crowd's many independent objects into one mesh with two animated poses.
fans=[o for o in s.objects if o.type=='EMPTY' and o.name.startswith('Cheering fan')]
verts=[];poseA=[];poseB=[];faces=[];mats=[];matidx=[];matmap={};rng=random.Random(52)
colors=[(.025,.05,.08),(.18,.08,.06),(.16,.20,.22),(.26,.17,.07),(.08,.17,.12),(.22,.11,.2),(.35,.3,.23)]
shirts=[material('Crowd clothing '+str(i),c) for i,c in enumerate(colors)]
skins=[material('Crowd skin '+str(i),c) for i,c in enumerate([(.52,.31,.20),(.30,.16,.08),(.68,.46,.33)])]
def addgeom(d,matrix,m,ma=None,mb=None):
    if m.name not in matmap:matmap[m.name]=len(mats);mats.append(m)
    offset=len(verts)
    for v in d.vertices:
        verts.append(matrix@v.co);poseA.append((ma or matrix)@v.co);poseB.append((mb or matrix)@v.co)
    for p in d.polygons:faces.append(tuple(offset+i for i in p.vertices));matidx.append(matmap[m.name])
for j,root in enumerate(fans):
    for child in root.children:
        if child.type!='MESH':continue
        d=child.data;m=shirts[j%len(shirts)] if 'torso' in child.name else skins[j%3]
        ma=mb=None
        if 'arm' in child.name:
            r=child.rotation_euler.copy();a=r.copy();b=r.copy();a.y+=.22*(-1 if j%2 else 1);b.y-=.20*(-1 if j%3 else 1)
            ma=root.matrix_world@Matrix.LocRotScale(child.location,a.to_quaternion(),child.scale)
            mb=root.matrix_world@Matrix.LocRotScale(child.location,b.to_quaternion(),child.scale)
        addgeom(d,child.matrix_world,m,ma,mb)
    # Ground each spectator with simple trousers.
    for side in [-1,1]:
        v=[(side*.11+x*.07,y*.09,.31+z*.31) for x,y,z in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]]
        offset=len(verts);world=[root.matrix_world@Vector(co) for co in v];verts.extend(world);poseA.extend(world);poseB.extend(world)
        for f in [(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)]:faces.append(tuple(offset+i for i in f));matidx.append(matmap[shirts[j%len(shirts)].name])
d=bpy.data.meshes.new('Festival audience');d.from_pydata(verts,[],faces);d.update()
for m in mats:d.materials.append(m)
for p,i in zip(d.polygons,matidx):p.material_index=i
crowd=bpy.data.objects.new('Festival audience with cheering poses',d);s.collection.objects.link(crowd);crowd.shape_key_add(name='Basis')
for name,coords,phase in [('Wave A',poseA,0),('Wave B',poseB,1.9)]:
    key=crowd.shape_key_add(name=name);key.data.foreach_set('co',[x for v in coords for x in v])
    for f in sorted(set(range(1849,2617,6))|{2065,2136,2616}):
        t=2065 if 2065<=f<=2136 else f
        key.value=.5+.48*math.sin((t-1849)*.035+phase);key.keyframe_insert('value',frame=f)
    for fc in d.shape_keys.animation_data.action.fcurves:
        for p in fc.keyframe_points:p.interpolation='LINEAR'
bpy.data.batch_remove([c for root in fans for c in root.children]+fans)
print('CROWD_MERGED',len(verts),flush=True)
# Three scenery groups allow render-time isolation of the active location.
static={0:[],1:[],2:[]}
for o in list(s.objects):
    if o.type !='MESH' or o.parent or o.animation_data or o.hide_render or o==crowd:continue
    if o.data.shape_keys if o.type=='MESH' else False:continue
    x=o.matrix_world.translation.x
    sector=0 if x<32 else 1 if x<47 else 2
    if o.name.startswith(('Festival','Soft distant','Lantern','Fairy','Stall')):sector=2
    static[sector].append(o)
for k,items in static.items():
    if items:merge(items,'Merged scenery '+str(k))
for o in s.objects:
    if o.type in {'MESH','CURVE'} and not o.hide_render:
        root=o
        while root.parent:root=root.parent
        x=root.matrix_world.translation.x
        sector=0 if x<32 else 1 if x<47 else 2
        if o.name.startswith('Merged scenery'):sector=int(o.name[-1])
        if o==crowd:sector=2
        o['render_sector']=sector
s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(Path(bpy.data.filepath).parent/'film_render_v2.blend'))
print('OPTIMIZED_OBJECTS',len(s.objects),flush=True)
