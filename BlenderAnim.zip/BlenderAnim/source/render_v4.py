"""Native full-frame rendering of the complete 113-second fourth edition.

Run two workers against the same .blend; atomic frame claims share the work.
Odd frames form a 12 fps source sequence for per-shot 24 fps interpolation.
The delivered .blend also supports a normal 24 fps Blender animation render.
"""
from pathlib import Path
import os
import sys
import time
import bpy

BASE=Path(__file__).resolve().parent
if BASE.name=='source':BASE=BASE.parent
scene=bpy.context.scene
scene.render.engine='BLENDER_EEVEE_NEXT'
scene.render.resolution_x=960;scene.render.resolution_y=540;scene.render.resolution_percentage=100
scene.render.use_border=False;scene.render.use_crop_to_border=False
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.compression=15
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
proof=bool(args and args[0]=='proof')
frames=[int(f) for f in args[1:]] if proof else range(1,2713,2)
edition=os.environ.get('BLENDER_ANIM_EDITION','V4')
folder=BASE/'output'/(os.environ.get('BLENDER_ANIM_PROOF_DIR','v4_native_proofs') if proof else os.environ.get('BLENDER_ANIM_FRAME_DIR','final_frames_v4'))
folder.mkdir(exist_ok=True);pending=folder/'.pending';pending.mkdir(exist_ok=True)
for frame in frames:
    destination=folder/f'{frame:05d}.png'
    if destination.exists():continue
    lock=pending/f'{frame:05d}.lock'
    try:
        fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
        os.write(fd,str(os.getpid()).encode());os.close(fd)
    except FileExistsError:continue
    try:
        scene.frame_set(frame)
        scene.eevee.taa_render_samples=8 if 649<=frame<745 or 1705<=frame<1849 else 4
        temporary=pending/f'{frame:05d}-{os.getpid()}.png'
        scene.render.filepath=str(temporary)
        start=time.time();bpy.ops.render.render(write_still=True)
        temporary.replace(destination)
        print(edition+'_FRAME_DONE',frame,round(time.time()-start,3),flush=True)
    finally:lock.unlink(missing_ok=True)
print(edition+'_RENDER_BATCH_COMPLETE',flush=True)
