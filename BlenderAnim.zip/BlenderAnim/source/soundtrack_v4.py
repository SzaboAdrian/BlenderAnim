"""Keep all synchronized cues, extend the concert by four seconds, add rain."""
from pathlib import Path
import wave
import numpy as np

BASE=Path(__file__).resolve().parent
if BASE.name=='source':BASE=BASE.parent
source=BASE/'output/final_mix.wav'
with wave.open(str(source),'rb') as stream:
    rate=stream.getframerate();assert stream.getnchannels()==2 and stream.getsampwidth()==2
    original=np.frombuffer(stream.readframes(stream.getnframes()),dtype='<i2').astype(np.float32).reshape(-1,2)/32767
assert len(original)==109*rate
# The four-second phrase is an integral number of beat and melody periods.
insert=original[85*rate:89*rate].copy()
mix=np.concatenate([original[:89*rate],insert,original[89*rate:]],axis=0)
for at in [89*rate,93*rate]:
    n=int(.012*rate)
    left=mix[at-n:at].copy();right=mix[at:at+n].copy()
    t=np.linspace(0,1,n)[:,None]
    # Smooth the discontinuity locally without changing the duration or cue times.
    midpoint=(left[-1]+right[0])/2
    mix[at-n:at]=left*(1-t**3)+midpoint*t**3
    mix[at:at+n]=midpoint*(1-t)**3+right*(1-(1-t)**3)
rng=np.random.default_rng(904)
length=52*rate
for channel in range(2):
    noise=rng.normal(0,1,length)
    rain=np.convolve(noise,np.ones(4)/4,'same')-.65*np.convolve(noise,np.ones(75)/75,'same')
    t=np.arange(length)/rate
    envelope=np.minimum(1,t/1.2)*np.clip((52-t)/1.2,0,1)*(.90+.10*np.sin(t*.6)**2)
    mix[:length,channel]+=rain*envelope*.022
for at in rng.uniform(.1,51.6,1450):
    n=int(.023*rate);t=np.arange(n)/rate
    drop=np.sin(2*np.pi*rng.uniform(1300,4200)*t)*np.exp(-t*rng.uniform(170,280))
    start=int(at*rate);pan=rng.uniform(.1,.9);gain=rng.uniform(.0018,.006)
    mix[start:start+n,0]+=drop*gain*pan;mix[start:start+n,1]+=drop*gain*(1-pan)
assert len(mix)==113*rate and np.max(np.abs(mix))<1
destination=BASE/'output/final_mix_v4.wav'
with wave.open(str(destination),'wb') as stream:
    stream.setparams((2,2,rate,0,'NONE','not compressed'))
    stream.writeframes((mix*32767).astype('<i2').tobytes())
print('V4_SOUNDTRACK',destination,'113 seconds',float(np.max(np.abs(mix))))
