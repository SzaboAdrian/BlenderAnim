"""Portable blue-hour finishing, printed shirts, and the closing dedication.

Run with Blender 4.3:
blender -b output/film_render_v2.blend --python finish_v3.py
All artwork is generated locally, packed in the .blend, and also supplied as
editable source assets. The grade is applied in display RGB after AgX, so the
same transform can finish the already rendered shots without another 3D pass.
"""
from pathlib import Path
import math
import shutil
import sys

import bpy
import numpy as np
from mathutils import Vector
from PIL import Image, ImageDraw, ImageFont, ImageFilter

BASE = Path(__file__).resolve().parent
if BASE.name == 'source':
    BASE = BASE.parent
OUT = BASE / 'output'
ASSETS = OUT / 'assets_v3'
QUOTE = 'Maybe in another life, there will be an opportunity, to be more than a dreamer, Adrian'
INK = (.55, .57, .64)
ACTORS = ['Narrator seated', 'Narrator at computer', 'Narrator on stage']
TITLE_KEYS = [(1, 0), (2269, 0), (2341, 1), (2557, 1), (2616, 0)]


def artwork():
    ASSETS.mkdir(exist_ok=True)
    font_dir = Path('/usr/share/fonts/truetype/dejavu')
    for filename in ['DejaVuSerif-Italic.ttf', 'DejaVuSans.ttf']:
        if not (ASSETS / filename).exists():
            shutil.copyfile(font_dir / filename, ASSETS / filename)
    if not (ASSETS / 'FONT_LICENSE.txt').exists():
        shutil.copyfile('/usr/share/doc/fonts-dejavu-core/copyright', ASSETS / 'FONT_LICENSE.txt')
    (ASSETS / 'closing_words.txt').write_text(QUOTE + '\n')

    # Shirt ink is stored as linear emission values; alpha is the print mask.
    shirt = Image.new('RGBA', (1024, 256))
    d = ImageDraw.Draw(shirt)
    font = ImageFont.truetype(str(ASSETS / 'DejaVuSans.ttf'), 205)
    bbox = d.textbbox((0, 0), 'Adrian', font=font)
    x = (1024 - (bbox[2] - bbox[0])) / 2 - bbox[0]
    y = (256 - (bbox[3] - bbox[1])) / 2 - bbox[1]
    d.text((x, y), 'Adrian', font=font, fill=tuple(round(c * 255) for c in INK) + (255,))
    shirt.save(ASSETS / 'adrian_shirt.png')

    # Twice the delivered resolution keeps the letters clean in a 720p render.
    size = (1920, 1080)
    title = Image.new('RGBA', size)
    gradient = np.zeros((1080, 1920, 4), dtype=np.uint8)
    gradient[:, :, :3] = (7, 8, 19)
    v = np.clip((np.arange(1080) - 690) / 390, 0, 1)
    gradient[:, :, 3] = (v[:, None] ** 1.5 * 68).astype(np.uint8)
    title = Image.alpha_composite(title, Image.fromarray(gradient))
    letters = Image.new('RGBA', size)
    d = ImageDraw.Draw(letters)
    italic = ImageFont.truetype(str(ASSETS / 'DejaVuSerif-Italic.ttf'), 44)
    signature = ImageFont.truetype(str(ASSETS / 'DejaVuSerif-Italic.ttf'), 52)
    for line, y in zip(['Maybe in another life,', 'there will be an opportunity,',
                        'to be more than a dreamer,'], [800, 860, 920]):
        d.text((960, y), line, font=italic, anchor='mm', fill=(228, 224, 239, 255))
    d.text((960, 1000), 'Adrian', font=signature, anchor='mm', fill=(230, 213, 198, 255))
    shadow = Image.new('RGBA', size, (0, 0, 0, 0))
    shadow.putalpha(letters.getchannel('A').filter(ImageFilter.GaussianBlur(5)).point(lambda x: round(x * .7)))
    title = Image.alpha_composite(Image.alpha_composite(title, shadow), letters)
    title.save(ASSETS / 'closing_title.png')


def image_asset(name, filename):
    image = bpy.data.images.load(str(ASSETS / filename), check_existing=False)
    image.name = name
    image.colorspace_settings.name = 'Non-Color'
    image.alpha_mode = 'STRAIGHT'
    image.pack()
    return image


def shirts(scene):
    image = image_asset('Adrian | shirt artwork (packed)', 'adrian_shirt.png')
    m = bpy.data.materials.new('Adrian | soft silver printed lettering')
    m.use_nodes = True
    m.surface_render_method = 'DITHERED'
    nodes = m.node_tree.nodes
    nodes.clear()
    texture = nodes.new('ShaderNodeTexImage'); texture.image = image
    texture.interpolation = 'Linear'; texture.extension = 'CLIP'
    emission = nodes.new('ShaderNodeEmission')
    transparent = nodes.new('ShaderNodeBsdfTransparent')
    mix = nodes.new('ShaderNodeMixShader')
    output = nodes.new('ShaderNodeOutputMaterial')
    links = m.node_tree.links
    links.new(texture.outputs['Color'], emission.inputs['Color'])
    links.new(texture.outputs['Alpha'], mix.inputs[0])
    links.new(transparent.outputs[0], mix.inputs[1])
    links.new(emission.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], output.inputs['Surface'])
    for sector, actor in enumerate(ACTORS):
        torso = bpy.data.objects[actor + ' torso']
        for side in ('front', 'back'):
            width = .34 if side == 'back' else .32
            height = width / 4
            sign = 1 if side == 'front' else -1
            y = -.143 * sign
            z = .11
            vertices = [(-sign * width/2, y, z-height/2),
                        (sign * width/2, y, z-height/2),
                        (sign * width/2, y, z+height/2),
                        (-sign * width/2, y, z+height/2)]
            mesh = bpy.data.meshes.new(f'{actor} Adrian {side}')
            mesh.from_pydata(vertices, [], [(0, 1, 2, 3)])
            mesh.update()
            uv = mesh.uv_layers.new(name='Print UV')
            for loop, coordinate in zip(uv.data, [(0,0), (1,0), (1,1), (0,1)]):
                loop.uv = coordinate
            obj = bpy.data.objects.new(mesh.name, mesh)
            scene.collection.objects.link(obj)
            obj.parent = torso
            mesh.materials.append(m)
            obj['shirt_print'] = True
            obj['render_sector'] = sector
            obj['print_side'] = side
            for frame in [1, 1248, 1249, 1848, 1849, 2616]:
                active = 0 if frame < 1249 else 1 if frame < 1849 else 2
                obj.hide_render = active != sector
                obj.keyframe_insert('hide_render', frame=frame)
            for fc in obj.animation_data.action.fcurves:
                for k in fc.keyframe_points:
                    k.interpolation = 'CONSTANT'


def grade_group():
    group = bpy.data.node_groups.new('Blue hour | melancholy display grade', 'CompositorNodeTree')
    group.interface.new_socket(name='Image', in_out='INPUT', socket_type='NodeSocketColor')
    group.interface.new_socket(name='Image', in_out='OUTPUT', socket_type='NodeSocketColor')
    nodes = group.nodes; links = group.links
    incoming = nodes.new('NodeGroupInput')
    outgoing = nodes.new('NodeGroupOutput')
    sep = nodes.new('CompositorNodeSeparateColor'); sep.mode = 'RGB'
    combine = nodes.new('CompositorNodeCombineColor'); combine.mode = 'RGB'
    links.new(incoming.outputs[0], sep.inputs['Image'])

    def op(operation, *values):
        node = nodes.new('CompositorNodeMath'); node.operation = operation
        for i, value in enumerate(values):
            if isinstance(value, (int, float)):
                node.inputs[i].default_value = value
            else:
                links.new(value, node.inputs[i])
        return node.outputs[0]

    channels = [sep.outputs[n] for n in ['Red', 'Green', 'Blue']]
    gray = op('ADD', op('ADD', op('MULTIPLY', channels[0], .2126),
                       op('MULTIPLY', channels[1], .7152)), op('MULTIPLY', channels[2], .0722))
    for i, (name, gain, tint) in enumerate(zip(['Red', 'Green', 'Blue'],
                                              [.94, .96, 1.02], [-.035, -.015, .065])):
        d = op('ADD', gray, op('MULTIPLY', op('SUBTRACT', channels[i], gray), .72))
        lift = op('SINE', op('MULTIPLY', d, math.pi))
        soft = op('ADD', op('MULTIPLY', d, .92), op('MULTIPLY', lift, .07))
        result = op('ADD', op('MULTIPLY', soft, gain), op('MULTIPLY', lift, tint))
        links.new(result, combine.inputs[name])
    links.new(combine.outputs['Image'], outgoing.inputs[0])
    # Lay out the mathematical graph instead of stacking nodes on top of each other.
    for i, node in enumerate(nodes):
        node.location = ((i % 8) * 190, -(i // 8) * 180)
    return group


def compositing(scene):
    scene.use_nodes = True
    tree = scene.node_tree; nodes = tree.nodes; links = tree.links
    fade = nodes['Editorial fades']
    composite = next(n for n in nodes if n.type == 'COMPOSITE')
    # The supplied final project can be used as input to rerun this script.
    for node in list(nodes):
        if node not in (nodes['Render Layers'], nodes['Glare'], fade, composite):
            nodes.remove(node)
    if tree.animation_data and tree.animation_data.action:
        for fc in list(tree.animation_data.action.fcurves):
            if 'Closing words opacity' in fc.data_path:
                tree.animation_data.action.fcurves.remove(fc)
    agx = nodes.new('CompositorNodeConvertColorSpace')
    agx.name = 'AgX display encoding'; agx.label = 'Preserve the original AgX rendering'
    agx.from_color_space = 'Linear Rec.709'; agx.to_color_space = 'AgX Base sRGB'
    grade = nodes.new('CompositorNodeGroup'); grade.node_tree = grade_group()
    grade.name = 'Melancholy blue hour'; grade.label = 'Muted colour · lavender shadows · soft highlights'
    title = nodes.new('CompositorNodeImage')
    title.name = 'Closing words'; title.image = image_asset('Closing words | serif italic (packed)', 'closing_title.png')
    scale = nodes.new('CompositorNodeScale'); scale.space = 'RENDER_SIZE'; scale.frame_method = 'FIT'
    straight = nodes.new('CompositorNodePremulKey'); straight.mapping = 'PREMUL_TO_STRAIGHT'
    visibility = nodes.new('CompositorNodeValue'); visibility.name = 'Closing words opacity'
    for frame, alpha in TITLE_KEYS:
        visibility.outputs[0].default_value = alpha
        visibility.outputs[0].keyframe_insert('default_value', frame=frame)
    for fc in tree.animation_data.action.fcurves:
        if 'Closing words opacity' in fc.data_path:
            for key in fc.keyframe_points:
                key.interpolation = 'BEZIER'; key.handle_left_type = 'AUTO_CLAMPED'; key.handle_right_type = 'AUTO_CLAMPED'
    alpha = nodes.new('CompositorNodeMath'); alpha.operation = 'MULTIPLY'
    # Separate alpha after scaling (the scale node exposes only Image).
    sep = nodes.new('CompositorNodeSeparateColor'); sep.mode = 'RGB'
    over = nodes.new('CompositorNodeMixRGB'); over.blend_type = 'MIX'; over.name = 'Closing dedication'
    linear = nodes.new('CompositorNodeConvertColorSpace')
    linear.name = 'Display RGB to output linear'; linear.from_color_space = 'sRGB'; linear.to_color_space = 'Linear Rec.709'
    links.new(fade.outputs[0], agx.inputs[0]); links.new(agx.outputs[0], grade.inputs[0])
    links.new(title.outputs['Image'], scale.inputs['Image']); links.new(scale.outputs['Image'], straight.inputs[0])
    links.new(straight.outputs[0], sep.inputs[0])
    links.new(sep.outputs['Alpha'], alpha.inputs[0]); links.new(visibility.outputs[0], alpha.inputs[1])
    links.new(alpha.outputs[0], over.inputs[0]); links.new(grade.outputs[0], over.inputs[1]); links.new(straight.outputs[0], over.inputs[2])
    links.new(over.outputs[0], linear.inputs[0]); links.new(linear.outputs[0], composite.inputs[0])
    for i, node in enumerate([nodes['Render Layers'], nodes['Glare'], fade, agx, grade, over, linear, composite]):
        node.location = (i * 220, 240)
    title.location = (440, -80); scale.location = (660, -80); straight.location = (880, -80); sep.location = (1100, -80)
    visibility.location = (880, -340); alpha.location = (1320, -80)
    scene.view_settings.view_transform = 'Standard'
    scene.view_settings.look = 'None'
    scene.view_settings.exposure = 0
    scene.view_settings.gamma = 1
    scene['closing_quote'] = QUOTE
    scene['finishing_notes'] = 'Blue/lavender melancholy grade after AgX. Packed shirt prints and closing serif title. No added grain.'


def studio_camera():
    # The old push crossed the back of the monitor. Keep the camera on the
    # performer's side of the desk throughout the push, with a clear eyeline.
    camera = bpy.data.objects['09 Studio face push']
    camera.animation_data_clear()
    camera.data.lens = 50
    for frame, location in [(1705, (41.85, -.20, 1.98)), (1848, (40.85, -.15, 1.79))]:
        camera.location = location
        camera.rotation_euler = (Vector((40, -1.06, 1.58)) - camera.location).to_track_quat('-Z', 'Y').to_euler()
        camera.keyframe_insert('location', frame=frame)
        camera.keyframe_insert('rotation_euler', frame=frame)
    for fc in camera.animation_data.action.fcurves:
        for key in fc.keyframe_points:
            key.interpolation = 'BEZIER'; key.handle_left_type = 'AUTO_CLAMPED'; key.handle_right_type = 'AUTO_CLAMPED'


def ink_calibration():
    """Render an emission-versus-fade lookup using Blender's actual AgX OCIO."""
    original = bpy.context.window.scene
    scene = bpy.data.scenes.new('Ink calibration temporary')
    bpy.context.window.scene = scene
    scene.render.engine = 'BLENDER_EEVEE_NEXT'; scene.eevee.taa_render_samples = 1
    scene.render.resolution_x = 1024; scene.render.resolution_y = 16; scene.render.resolution_percentage = 100
    camera = bpy.data.objects.new('Calibration camera', bpy.data.cameras.new('Calibration camera'))
    scene.collection.objects.link(camera); scene.camera = camera
    image = bpy.data.images.new('Calibration values', width=1024, height=16, alpha=True, float_buffer=True)
    image.colorspace_settings.name = 'Non-Color'
    values = np.ones((16, 1024, 4), dtype=np.float32)
    # Use the texture's quantized ink values, not the pre-quantization constants.
    values[:, :, :3] = np.linspace(0, 1, 1024)[None, :, None] * (np.round(np.array(INK) * 255) / 255)[None, None, :]
    image.pixels.foreach_set(values.ravel())
    scene.use_nodes = True; tree = scene.node_tree; tree.nodes.clear()
    source = tree.nodes.new('CompositorNodeImage'); source.image = image
    target = tree.nodes.new('CompositorNodeComposite')
    tree.links.new(source.outputs[0], target.inputs[0])
    scene.view_settings.view_transform = 'AgX'; scene.view_settings.look = 'None'
    scene.render.image_settings.file_format = 'PNG'; scene.render.image_settings.color_mode = 'RGB'
    scene.render.filepath = str(ASSETS / 'ink_agx_lookup.png')
    bpy.ops.render.render(write_still=True)
    bpy.context.window.scene = original
    bpy.data.scenes.remove(scene)
    bpy.data.objects.remove(camera, do_unlink=True)
    bpy.data.images.remove(image)


if __name__ == '__main__':
    artwork()
    scene = bpy.context.scene
    for obj in list(bpy.data.objects):
        if obj.get('shirt_print'):
            bpy.data.objects.remove(obj, do_unlink=True)
    shirts(scene)
    studio_camera()
    compositing(scene)
    ink_calibration()
    scene.frame_set(2401)
    scene.render.engine = 'BLENDER_EEVEE_NEXT'
    scene.eevee.taa_render_samples = 32
    scene.render.resolution_x = 1280; scene.render.resolution_y = 720
    scene.render.resolution_percentage = 100
    scene.render.image_settings.file_format = 'FFMPEG'
    scene.render.ffmpeg.format = 'MPEG4'; scene.render.ffmpeg.codec = 'H264'
    scene.render.ffmpeg.audio_codec = 'AAC'; scene.render.ffmpeg.audio_bitrate = 192
    scene.render.filepath = '//BlenderAnim_final.mp4'
    bpy.ops.wm.save_as_mainfile(filepath=str(OUT / 'film_render_v3.blend'))
    print('V3_PROJECT_READY', flush=True)
