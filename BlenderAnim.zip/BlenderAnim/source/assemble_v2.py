"""Encode full shots independently, preserving hard cuts during optical interpolation."""
from pathlib import Path
import subprocess,json,sys
BASE=Path(__file__).resolve().parent;OUT=BASE/'output';FRAMES=OUT/'final_frames';CUTS=[1,193,313,505,649,745,1033,1249,1705,1849,2137,2617]
segments=OUT/'encoded_shots';segments.mkdir(exist_ok=True)
for number,(start,end) in enumerate(zip(CUTS,CUTS[1:]),1):
    frames=list(range(start,end,2));dest=segments/f'{number:02d}.mp4'
    expected=(end-start)/24
    if dest.exists():
        try:
            duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(dest)]))
            if abs(duration-expected)<.01:continue
        except (ValueError,subprocess.CalledProcessError):pass
    missing=[f for f in frames if not (FRAMES/f'{f:05d}.png').exists()]
    if missing:
        if '--available' in sys.argv:continue
        raise RuntimeError(f'Shot {number}: missing {len(missing)} frames, first={missing[0]}')
    links=segments/f'input_{number:02d}';links.mkdir(exist_ok=True)
    for i,f in enumerate(frames):
        p=links/f'{i:05d}.png'
        if not p.exists():p.symlink_to(FRAMES/f'{f:05d}.png')
    count=end-start
    filters=f'tpad=start_mode=clone:start_duration=0.166667:stop_mode=clone:stop_duration=0.25,minterpolate=fps=24:mi_mode=mci:mc_mode=aobmc:vsbmc=1:scd=none,trim=start_frame=4:end_frame={count+4},setpts=PTS-STARTPTS'
    cmd=['ffmpeg','-y','-loglevel','warning','-threads','1','-filter_threads','1','-framerate','12','-i',str(links/'%05d.png'),'-vf',filters,'-frames:v',str(count),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-r','24','-movflags','+faststart',str(dest)]
    subprocess.run(cmd,check=True);print('ENCODED_SHOT',number,'frames',count,flush=True)
if not all((segments/f'{i:02d}.mp4').exists() for i in range(1,12)):
    print('WAITING_FOR_REMAINING_SHOTS',flush=True);sys.exit(0)
listing=segments/'concat.txt';listing.write_text(''.join("file '"+str(segments/f'{i:02d}.mp4')+"'\n" for i in range(1,12)))
final=OUT/'BlenderAnim_final.mp4'
subprocess.run(['ffmpeg','-y','-loglevel','warning','-f','concat','-safe','0','-i',str(listing),'-i',str(OUT/'final_mix.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','109','-movflags','+faststart',str(final)],check=True)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=codec_type,codec_name,width,height,r_frame_rate,nb_read_frames:format=duration','-of','json',str(final)]))
v=next(x for x in info['streams'] if x['codec_type']=='video');a=next(x for x in info['streams'] if x['codec_type']=='audio')
assert v['nb_read_frames']=='2616' and v['r_frame_rate']=='24/1' and abs(float(info['format']['duration'])-109)<.1
subprocess.run(['ffmpeg','-v','error','-i',str(final),'-f','null','-'],check=True)
(OUT/'video_validation.json').write_text(json.dumps(info,indent=2));print('FINAL_VIDEO_VERIFIED',str(final),json.dumps(info),flush=True)
