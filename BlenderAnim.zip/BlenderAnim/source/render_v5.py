"""Render fifth-edition frames with the shared native Blender renderer."""
from pathlib import Path
import os
import runpy
os.environ.update(BLENDER_ANIM_EDITION='V5',BLENDER_ANIM_FRAME_DIR='final_frames_v5',BLENDER_ANIM_PROOF_DIR='v5_native_proofs')
runpy.run_path(str(Path(__file__).with_name('render_v4.py')),run_name='__main__')
