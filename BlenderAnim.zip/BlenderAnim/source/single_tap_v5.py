"""Remove five later presses while preserving the first press and every cut.

Input: the fourth-edition .blend. Only the repeated right-hand actions and the
spacebar key are changed. The following checks use actual evaluated animation.
"""
from pathlib import Path
import json
import math
import sys
import bpy
from mathutils import Vector

BASE=Path(__file__).resolve().parent
if BASE.name=='source':BASE=BASE.parent
sys.path.insert(0,str(Path(__file__).resolve().parent))
from animation_v2 import ik

OUT=BASE/'output';scene=bpy.context.scene
REMOVED=[1381,1489,1597,1705,1813]
EDIT_FRAMES={f for tap in REMOVED for f in range(tap,tap+25)}
RENDER_FRAMES=sorted({f for tap in REMOVED for f in range(tap-2,tap+27) if f%2})
upper=scene.objects['Narrator at computer upper arm.001']
lower=scene.objects['Narrator at computer forearm.001']
joint=scene.objects['Narrator at computer elbow.001']
hand=scene.objects['Narrator at computer hand.001']
space=scene.objects['Spacebar']
objects=[upper,lower,joint,hand,space]
markers=[(m.frame,m.camera.name if m.camera else None) for m in scene.timeline_markers]
original={o.name:{(fc.data_path,fc.array_index):[(int(k.co.x),float(k.co.y)) for k in fc.keyframe_points]
                  for fc in o.animation_data.action.fcurves} for o in objects}

def bone(obj,a,b,frame):
    old=obj.rotation_quaternion.copy()
    obj.location=(a+b)/2;obj.keyframe_insert('location',frame=frame)
    q=(b-a).to_track_quat('Z','Y');q.make_compatible(old)
    obj.rotation_quaternion=q;obj.keyframe_insert('rotation_quaternion',frame=frame)

for frame in sorted(EDIT_FRAMES):
    scene.frame_set(frame)
    idle=.003*math.sin(frame*math.tau/(24*4.5))
    shoulder=Vector((.28,-.03,1.30+idle))
    elbow,wrist,_=ik(shoulder,Vector((.22,-.53,1.07)),.31,.32,(1,-.15,-.5))
    bone(upper,shoulder,elbow,frame);bone(lower,elbow,wrist,frame)
    joint.location=elbow;joint.keyframe_insert('location',frame=frame)
    hand.location=wrist;hand.keyframe_insert('location',frame=frame)
    space.location=(40,-.43,1.014);space.keyframe_insert('location',frame=frame)
for obj in objects:
    for fc in obj.animation_data.action.fcurves:
        if fc.data_path in ('location','rotation_quaternion'):
            for key in fc.keyframe_points:key.interpolation='LINEAR'
        before=original[obj.name][(fc.data_path,fc.array_index)]
        assert len(before)==len(fc.keyframe_points)
        for (f,value),key in zip(before,fc.keyframe_points):
            if f not in EDIT_FRAMES:assert float(key.co.y)==value,(obj.name,fc.data_path,f)
assert markers==[(m.frame,m.camera.name if m.camera else None) for m in scene.timeline_markers]
assert scene.frame_end==2712 and scene.render.fps==24

# Count complete press episodes, verify the steady wrist after release, and
# check the physical elbow/wrist connections across every studio frame.
episodes=[];key_episodes=[];in_press=False;in_key=False;max_gap=0;min_dot=1;previous={}
for frame in range(1249,1849):
    scene.frame_set(frame)
    press=hand.location.z<1.065;key_press=space.location.z<1.012
    if press and not in_press:episodes.append(frame)
    if key_press and not in_key:key_episodes.append(frame)
    in_press=press;in_key=key_press
    if frame>=1297:
        assert abs(hand.location.z-1.07)<1e-6
        assert abs(space.location.z-1.014)<1e-6
    a=upper.matrix_local@Vector((0,0,.155));b=lower.matrix_local@Vector((0,0,-.16))
    c=lower.matrix_local@Vector((0,0,.16))
    max_gap=max(max_gap,(a-b).length,(c-hand.location).length)
    for obj in (upper,lower):
        q=obj.rotation_quaternion.copy()
        if obj.name in previous:min_dot=min(min_dot,q.dot(previous[obj.name]))
        previous[obj.name]=q
assert len(episodes)==len(key_episodes)==1 and 1273<=episodes[0]<=1280
assert max_gap<.00002 and min_dot>.995,(max_gap,min_dot)
if scene.sequence_editor:
    for seq in list(scene.sequence_editor.sequences):scene.sequence_editor.sequences.remove(seq)
scene.sequence_editor_create().sequences.new_sound('Single play press, rain and complete soundtrack',str(OUT/'final_mix_v5.wav'),channel=1,frame_start=1)
for sound in list(bpy.data.sounds):
    if sound.users==0:bpy.data.sounds.remove(sound)
    elif Path(sound.filepath).name=='final_mix_v5.wav':sound.filepath='//final_mix_v5.wav'
scene['edition']=5;scene['keyboard_tap_frames']=[1273];scene['keyboard_press_count']=1
if 'keyboard_press_interval_seconds' in scene:del scene['keyboard_press_interval_seconds']
scene['final_duration_seconds']=113;scene['studio_sequence_duration_seconds']=25
scene['finishing_notes']='Single keyboard press starts continuous music. Studio side shot 19 seconds; face push 6 seconds. Rain, refined portrait, plain shirt, stage greeting and closing dedication.'
readme=bpy.data.texts.get('READ ME — Melancholy edition')
if readme:
    readme.clear();readme.write('Edition 5 — 113 seconds, 24 fps.\n\nOne studio keyboard press at frame 1273.\nThe side shot lasts 19 seconds and the face push 6 seconds.\nKeep final_mix_v5.wav next to this .blend.\n\nThe packed closing dedication and blue-hour grade are in the compositor.\n'+scene['closing_quote'])
scene.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'film_render_v5.blend'))
report={'press_count':1,'press_start_frame':1273,'observed_press_episode_starts':episodes,
        'observed_key_episode_starts':key_episodes,'studio_side_shot_seconds':19,
        'studio_face_shot_seconds':6,'studio_total_seconds':25,'movie_seconds':113,
        'all_cut_frames_preserved':True,'first_press_and_other_keys_preserved':True,
        'max_joint_gap_m':max_gap,'min_adjacent_quaternion_dot':min_dot,
        'render_frames':RENDER_FRAMES}
(OUT/'single_tap_validation_v5.json').write_text(json.dumps(report,indent=2))
print('V5_SINGLE_PRESS_VERIFIED',json.dumps(report),flush=True)
