"""Produce and verify the complete fifth-edition movie with unchanged timing."""
from pathlib import Path
import os
import runpy
os.environ.update(BLENDER_ANIM_EDITION='V5',BLENDER_ANIM_FRAME_DIR='final_frames_v5',
                  BLENDER_ANIM_SEGMENT_DIR='encoded_v5',BLENDER_ANIM_SOUND='final_mix_v5.wav',
                  BLENDER_ANIM_FILM='BlenderAnim_v5.mp4',BLENDER_ANIM_REPORT='video_validation_v5.json')
runpy.run_path(str(Path(__file__).with_name('assemble_v4.py')),run_name='__main__')
