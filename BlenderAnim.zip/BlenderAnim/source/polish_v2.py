"""Lighting, the idea-bulb beat, transitions and a landscaped festival site."""
import bpy, math, random
from mathutils import Vector
from geometry_v2 import *
from animation_v2 import TAPS, END, ease

def apply(s):
    rng=random.Random(731)
    for o in list(s.objects):
        if o.type=='FONT' and ('BUS' in o.data.body or '24' in o.data.body):bpy.data.objects.remove(o,do_unlink=True)
    # The old white advertising board is replaced by a quiet glass panel.
    glass=material('Quiet blue shelter glass',(.13,.23,.25),rough=.32,metal=.12)
    for name in ['Shelter poster backing','Bus stop sign']:
        o=s.objects.get(name)
        if o:o.hide_render=True;o.hide_viewport=True
    box('Glass shelter lower back',(0,.73,1.90),(3.9,.035,.80),glass)
    grass=material('Festival lawn',(.055,.12,.075));soil=material('Festival footpaths',(.16,.13,.10));trunk=material('Dark cedar trunks',(.07,.035,.025))
    leaves=[material('Forest foliage '+str(i),c) for i,c in enumerate([(.035,.11,.065),(.055,.15,.08),(.08,.18,.095)])]
    warm=material('Warm fairy lights',(1,.42,.08),emission=4);violet=material('Stage violet glow',(.27,.025,.8),emission=3)
    navy=material('Festival tent canvas',(.025,.07,.11));sage=material('Festival tent sage',(.10,.2,.16));gold=material('Brass accents',(.36,.21,.06),rough=.3,metal=.55)
    stone=material('River stones',(.18,.21,.23));wood=material('Festival timber',(.16,.07,.025));white=material('Soft white details',(.8,.82,.75))
    box('Festival surrounding ground',(80,12,-.31),(150,135,.3),grass)
    box('Festival entry path',(80,46,-.13),(9,30,.07),soil)
    for side in [-1,1]:box('Festival side path',(80+side*27,18,-.12),(4,45,.07),soil)
    # Distant hills and layered groves frame the high camera shot.
    for i in range(18):
        a=math.tau*i/18;x=20+i*7;y=rng.uniform(60,75)
        sphere('Soft distant hill',(x,y,-3),(rng.uniform(12,20),rng.uniform(10,17),rng.uniform(6,13)),leaves[i%3],n=16,r=8)
    for i in range(105):
        side=-1 if i%2 else 1;x=rng.uniform(51,56) if side<0 else rng.uniform(110,129);y=rng.uniform(-11,52);h=rng.uniform(2.8,6.5)
        rod('Festival tree trunk',(x,y,-.1),(x,y,h*.66),.12,trunk)
        for k in range(3):sphere('Festival tree crown',(x+(k-1)*.3,y,h*(.65+.13*k)),(h*.27,h*.24,h*.28),leaves[(i+k)%3],n=10,r=6)
    # Small tents and lantern-lit relaxation spaces on both sides.
    for side in [-1,1]:
        for j in range(4):
            x=80+side*30;y=7+j*9
            box('Festival stall base',(x,y,.6),(3.5,3.3,1.2),wood)
            v=[(-2,-2,2),(2,-2,2),(2,2,2),(-2,2,2),(0,0,3.2)]
            roof=mesh('Festival tent roof',v,[(0,1,4),(1,2,4),(2,3,4),(3,0,4)],navy if j%2 else sage);roof.location=(x,y,0)
            for dx in [-1.8,1.8]:rod('Stall post',(x+dx,y-1.8,0),(x+dx,y-1.8,2.1),.045,wood)
            box('Stall counter glow',(x,y-1.67,1.25),(2.7,.06,.04),warm)
    for side in [-1,1]:
        x=80+side*25
        for y in [0,10,20,30,40]:
            rod('Lantern pole',(x,y,0),(x,y,4.2),.045,wood)
            sphere('Lantern',(x,y,4.2),(.15,.15,.23),warm,n=10,r=6)
        for j in range(4):
            for k in range(13):
                y=j*10+k*10/12;z=4.2-.6*math.sin(math.pi*k/12)
                if k<12:rod('Fairy light wire',(x,y,z),(x,y+10/12,4.2-.6*math.sin(math.pi*(k+1)/12)),.009,trunk)
                if k%2==0:sphere('Fairy light',(x,y,z),(.065,.065,.08),warm,n=8,r=6)
    for i in range(50):
        x=rng.uniform(-18,18);y=rng.choice([-3.1,6.2])+rng.uniform(-.5,.5)
        sphere('Stop meadow stone',(x,y,.02),(.1,.08,.06),stone,n=8,r=5)
        for k in range(3):
            xx=x+rng.uniform(-.2,.2);yy=y+rng.uniform(-.2,.2)
            rod('Wildflower stem',(xx,yy,0),(xx,yy,.20),.006,leaves[0])
            sphere('Wildflower',(xx,yy,.21),(.035,.035,.018),warm if i%2 else white,n=6,r=4)
    # Add actual visible keys and a discreet studio side practical.
    metal=bpy.data.materials['Metal']
    for row in range(4):
        for col in range(13):box('Computer key',(39.54+col*.073,-.43+row*.068,1.006),(.058,.046,.014),white)
    space=s.objects.get('Spacebar')
    if space:
        for f in range(1249,1849):
            p=max(ease((f-t)/7)*(1-ease((f-t-15)/9)) for t in TAPS);keys(space,f,(40,-.43,1.014-.012*p))
        linear(space)
    for x in [36,38,42,44]:box('Panel violet edge',(x,1.60,1.55),(.9,.025,.018),violet)
    sphere('Studio plant pot',(42.2,.5,.42),(.28,.28,.4),navy)
    for i in range(7):
        a=i*math.tau/7;rod('Studio plant stem',(42.2,.5,.6),(42.2+.3*math.cos(a),.5+.3*math.sin(a),1.4),.013,leaves[0])
        leaf=sphere('Studio plant leaf',(42.2+.28*math.cos(a),.5+.28*math.sin(a),1.25),(.09,.05,.27),leaves[1]);leaf.rotation_euler=(.3*math.sin(a),.3*math.cos(a),a)
    # Warm lightbulb: a clear onset, gentle settle, tiny rays and a real light.
    root=empty('Idea bulb',(.75,-.32,2.08))
    bulbmat=material('Idea bulb warm glass',(1,.63,.16),emission=5)
    sphere('Idea glowing globe',(0,0,.10),(.105,.105,.13),bulbmat,root,n=24,r=16)
    box('Idea bulb neck',(0,0,-.035),(.095,.09,.09),gold,root,.015)
    for z in [-.055,-.035,-.015]:rod('Idea socket thread',(-.054,-.05,z),(.054,-.05,z),.007,gold,root)
    for i in range(7):
        a=math.pi*i/6;start=(.20*math.cos(a),0,.10+.20*math.sin(a));end=(.28*math.cos(a),0,.10+.28*math.sin(a));rod('Idea light ray',start,end,.009,bulbmat,root)
    for f,v in [(1,0),(1141,0),(1148,1.1),(1158,1),(1200,1),(1235,0),(END,0)]:keys(root,f,scale=(v,)*3)
    light=bpy.data.lights.new('Idea gentle face glow','POINT');light.color=(1,.56,.12);light.shadow_soft_size=.3
    o=bpy.data.objects.new('Idea gentle face glow',light);s.collection.objects.link(o);o.location=(.75,-.65,2.14)
    for f,e in [(1,0),(1141,0),(1148,12),(1200,12),(1235,0)]:light.energy=e;light.keyframe_insert('energy',frame=f)
    # Broader, kinder light on skin and a low evening sun.
    for name,energy in [('Stop softbox',500),('Evening sky fill',1100),('Studio violet',280),('Studio face',130),('Audience wash',6500)]:
        o=s.objects.get(name)
        if o:o.data.energy=energy
    d=bpy.data.lights.new('Golden hour sun','SUN');d.energy=1.35;d.color=(1,.77,.52);d.angle=.18
    sun=bpy.data.objects.new('Golden hour sun',d);s.collection.objects.link(sun);sun.rotation_euler=(.45,-.5,-.8)
    for f,e in [(1,1.35),(1248,1.35),(1249,0),(1848,0),(1849,.10),(END,.10)]:d.energy=e;d.keyframe_insert('energy',frame=f)
    for fc in d.animation_data.action.fcurves:
        for p in fc.keyframe_points:p.interpolation='CONSTANT'
    bg=s.world.node_tree.nodes.get('Background')
    for f,c,v in [(1,(.22,.35,.48,1),.6),(1248,(.22,.35,.48,1),.6),(1249,(.07,.05,.13,1),.2),(1848,(.07,.05,.13,1),.2),(1849,(.07,.12,.24,1),.4),(END,(.07,.12,.24,1),.4)]:
        bg.inputs[0].default_value=c;bg.inputs[0].keyframe_insert('default_value',frame=f);bg.inputs[1].default_value=v;bg.inputs[1].keyframe_insert('default_value',frame=f)
    if s.world.node_tree.animation_data:
        for fc in s.world.node_tree.animation_data.action.fcurves:
            for p in fc.keyframe_points:p.interpolation='CONSTANT'
    # Show the complete approach, including the planted feet.
    cam=s.timeline_markers['03 You sit down'].camera;cam.animation_data_clear();cam.data.lens=38
    for f,pos in [(313,(4,-9,3.2)),(504,(3,-8,2.8))]:
        keys(cam,f,pos,(Vector((.7,-.1,1.1))-Vector(pos)).to_track_quat('-Z','Y').to_euler())
    # Reframe the idea so the whole bulb stays inside the shot.
    cam=s.timeline_markers['07 Alone thinking'].camera;cam.animation_data_clear();cam.data.lens=50
    for f,pos,target in [(1033,(3,-5,2.4),(.75,-.3,1.45)),(1248,(1.1,-3.9,2.0),(.75,-.3,1.75))]:
        keys(cam,f,pos,(Vector(target)-Vector(pos)).to_track_quat('-Z','Y').to_euler())
    # Ease the drone into a much longer departure, keeping the landscape in view.
    cam=s.timeline_markers['11 Drone pull away'].camera;cam.animation_data_clear();cam.data.lens=28
    for f in range(2137,END+1,2):
        t=ease((f-2137)/(END-2137));pos=Vector((80,-9,7)).lerp(Vector((80,-44,40)),t);target=Vector((80,10,0)).lerp(Vector((80,15,0)),t)
        keys(cam,f,pos,(target-pos).to_track_quat('-Z','Y').to_euler())
    linear(cam)
    # Glow before fades means true black remains true black.
    tree=s.node_tree;tree.nodes.clear();tree.animation_data_clear()
    rl=tree.nodes.new('CompositorNodeRLayers');rl.scene=s
    glow=tree.nodes.new('CompositorNodeGlare');glow.glare_type='FOG_GLOW';glow.quality='MEDIUM';glow.threshold=1.6;glow.size=7;glow.mix=-.85
    mix=tree.nodes.new('CompositorNodeMixRGB');mix.name='Editorial fades';mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1
    out=tree.nodes.new('CompositorNodeComposite');tree.links.new(rl.outputs['Image'],glow.inputs['Image']);tree.links.new(glow.outputs['Image'],mix.inputs[1]);tree.links.new(mix.outputs[0],out.inputs[0])
    for f,v in [(1,0),(25,1),(1200,1),(1248,0),(1249,0),(1273,1),(1812,1),(1848,0),(1849,0),(1885,1),(2570,1),(2616,0)]:
        mix.inputs[2].default_value=(v,v,v,1);mix.inputs[2].keyframe_insert('default_value',frame=f)
    for fc in tree.animation_data.action.fcurves:
        for p in fc.keyframe_points:p.interpolation='BEZIER';p.handle_left_type='AUTO_CLAMPED';p.handle_right_type='AUTO_CLAMPED'
    s.render.engine='BLENDER_EEVEE_NEXT';s.eevee.taa_render_samples=16
    s.render.resolution_x=1280;s.render.resolution_y=720;s.render.resolution_percentage=100
    s.render.image_settings.file_format='PNG';s.render.image_settings.color_mode='RGB';s.view_settings.view_transform='AgX'
    s['film_version']='2 — slower movement, pause beats, idea light, festival landscape'
    s['keyboard_press_interval_seconds']=4.5;s['final_duration_seconds']=109
    s.frame_set(1)
