"""Assemble all eleven native-rendered shots into the complete 113-second film."""
from pathlib import Path
import json
import subprocess
import sys
import time

BASE=Path(__file__).resolve().parent
if BASE.name=='source':BASE=BASE.parent
OUT=BASE/'output';FRAMES=OUT/'final_frames_v4';SEGMENTS=OUT/'encoded_v4'
CUTS=[1,193,313,505,649,745,1033,1249,1705,1849,2233,2713]
SEGMENTS.mkdir(exist_ok=True)
for number,(start,end) in enumerate(zip(CUTS,CUTS[1:]),1):
    destination=SEGMENTS/f'{number:02d}.mp4';expected=(end-start)/24
    if destination.exists():
        try:
            duration=float(subprocess.check_output(['ffprobe','-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',str(destination)]))
            if abs(duration-expected)<.01:continue
        except (ValueError,subprocess.CalledProcessError):pass
    frames=list(range(start,end,2))
    missing=[f for f in frames if not (FRAMES/f'{f:05d}.png').exists()]
    if missing and '--follow' not in sys.argv:
        if '--available' in sys.argv:continue
        raise RuntimeError(f'Shot {number}: {len(missing)} missing frames, first={missing[0]}')
    links=SEGMENTS/f'input_{number:02d}';links.mkdir(exist_ok=True)
    for i,frame in enumerate(frames):
        link=links/f'{i:05d}.png'
        if not link.exists():link.symlink_to(FRAMES/f'{frame:05d}.png')
    count=end-start
    filters=f'tpad=start_mode=clone:start_duration=0.166667:stop_mode=clone:stop_duration=0.25,minterpolate=fps=24:mi_mode=mci:mc_mode=aobmc:vsbmc=1:scd=none,trim=start_frame=4:end_frame={count+4},setpts=PTS-STARTPTS'
    inputs=['-f','image2pipe','-vcodec','png','-framerate','12','-i','pipe:0'] if missing else ['-framerate','12','-i',str(links/'%05d.png')]
    command=['ffmpeg','-y','-loglevel','warning','-threads','1','-filter_threads','1',*inputs,'-vf',filters,'-frames:v',str(count),'-c:v','libx264','-preset','medium','-crf','19','-pix_fmt','yuv420p','-r','24','-movflags','+faststart',str(destination)]
    if missing:
        with subprocess.Popen(command,stdin=subprocess.PIPE) as process:
            for frame in frames:
                source=FRAMES/f'{frame:05d}.png'
                while not source.exists():
                    if process.poll() is not None:raise RuntimeError('Encoder stopped while waiting for a render')
                    time.sleep(.25)
                process.stdin.write(source.read_bytes())
            process.stdin.close()
            result=process.wait()
            if result:raise subprocess.CalledProcessError(result,command)
    else:subprocess.run(command,check=True)
    print('V4_ENCODED_SHOT',number,'frames',count,flush=True)
if not all((SEGMENTS/f'{i:02d}.mp4').exists() for i in range(1,12)):
    print('WAITING_FOR_REMAINING_SHOTS',flush=True);sys.exit(0)
listing=SEGMENTS/'concat.txt'
listing.write_text(''.join("file '"+str(SEGMENTS/f'{i:02d}.mp4')+"'\n" for i in range(1,12)))
final=OUT/'BlenderAnim_v4.mp4'
subprocess.run(['ffmpeg','-y','-loglevel','warning','-f','concat','-safe','0','-i',str(listing),'-i',str(OUT/'final_mix_v4.wav'),'-map','0:v:0','-map','1:a:0','-c:v','copy','-c:a','aac','-b:a','192k','-t','113','-movflags','+faststart',str(final)],check=True)
info=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_entries','stream=codec_type,codec_name,width,height,r_frame_rate,nb_read_frames:format=duration','-of','json',str(final)]))
video=next(x for x in info['streams'] if x['codec_type']=='video')
audio=next(x for x in info['streams'] if x['codec_type']=='audio')
assert video['nb_read_frames']=='2712' and video['r_frame_rate']=='24/1'
assert abs(float(info['format']['duration'])-113)<.1 and audio['codec_name']=='aac'
subprocess.run(['ffmpeg','-v','error','-i',str(final),'-f','null','-'],check=True)
(OUT/'video_validation_v4.json').write_text(json.dumps(info,indent=2))
print('V4_COMPLETE_FILM_VERIFIED',json.dumps(info),flush=True)
