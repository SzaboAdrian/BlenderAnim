# Fifth edition — one studio keyboard press, same shot lengths

The studio performance now contains exactly one deliberate hand press and one
spacebar depression, starting at frame 1273. The first press is preserved. The
five later press actions are replaced with a resting hand and an unpressed key.
Arm movement caused by gentle breathing remains connected at the elbow and wrist.

The side view is still frames 1249–1704 (19 seconds), followed by the face push
at frames 1705–1848 (6 seconds). Every camera cut is unchanged. The complete
film remains **2,712 frames at 24 fps, or 113 seconds**.

One keyboard click at 53.30 seconds starts a continuing original instrumental
beat. It fades into the existing studio-to-stage transition. The sound mix
outside 52–77 seconds is preserved sample for sample at the PCM source level.
The rain, refined face, dark brown hair, plain shirt, stage greeting, 20-second
drone departure, melancholy grade and exact closing dedication are included.

Open `output/bus_stop_to_stage.blend` in Blender 4.3 or newer and keep
`final_mix_v5.wav` beside it. The closing artwork is packed. Render → Render
Animation produces the complete native animation, configured for 1280 × 720,
24 fps and 32 EEVEE samples. The supplied complete MP4 is 960 × 540, H.264/AAC,
24 fps, using native 12 fps source frames and optical interpolation within each
shot. The source PNG cache is omitted from the download.

Sources:

- `single_tap_v5.py` upgrades the fourth-edition project. It changes only the five
  later right-hand press windows and their spacebar keys, preserves all other
  animation key values, and verifies the evaluated press count, joint contacts,
  quaternion continuity and unchanged shot boundaries.
- `soundtrack_v5.py` replaces only the studio interval of the fourth-edition mix.
  It synthesizes one click and a continuous beat and verifies the unchanged PCM
  samples outside the studio interval.
- `render_v5.py` uses the shared `render_v4.py` native renderer. It can render the
  supplied finished project without earlier scene files or cached images.
- `assemble_v5.py` uses the shared `assemble_v4.py` encoder to create and verify the
  whole 113-second movie. FFmpeg and FFprobe are needed for this optional workflow.
- `prepare_v5_frames.py` is an optional production optimization requiring the
  fourth-edition cache. Unchanged frames and nine complete encoded shots are
  reused; 75 source frames around the removed gestures are rendered again, and
  the two studio shots are re-encoded. A normal native Blender render does not
  need this cache.

Earlier geometry and scene helpers are retained as production references. The
finished `.blend` is the starting point for ordinary editing. Included validation
records document one hand/key press, preserved timing, portable assets, the
complete video frame count and successful full-file decoding.
