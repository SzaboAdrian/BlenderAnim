import bpy,sys
from pathlib import Path
s=bpy.context.scene
base=Path(__file__).resolve().parent/'output'
# Rebind the portable full soundtrack and store export settings.
if s.sequence_editor:
    for seq in list(s.sequence_editor.sequences):s.sequence_editor.sequences.remove(seq)
seq=s.sequence_editor_create();seq.sequences.new_sound('Final music, ambience and cues',str(base/'final_mix.wav'),channel=1,frame_start=1)
for sound in bpy.data.sounds:
    if Path(sound.filepath).name=='final_mix.wav':sound.filepath='//final_mix.wav'
for l in bpy.data.lights:
    if l.type in {'POINT','SPOT'} or l.name in ['Audience wash','Evening sky fill']:l.use_shadow=False
s.render.resolution_x=1280;s.render.resolution_y=720;s.render.resolution_percentage=100;s.eevee.taa_render_samples=32
s.render.image_settings.file_format='FFMPEG';s.render.ffmpeg.format='MPEG4';s.render.ffmpeg.codec='H264';s.render.ffmpeg.audio_codec='AAC';s.render.ffmpeg.constant_rate_factor='HIGH';s.render.filepath='//BlenderAnim_final.mp4'
for o in s.objects:
    if 'render_sector' not in o:continue
    sector=o['render_sector']
    for f,active in [(1,0),(1248,0),(1249,1),(1848,1),(1849,2),(2616,2)]:
        o.hide_render=sector!=active;o.keyframe_insert('hide_render',frame=f)
    for fc in o.animation_data.action.fcurves:
        if fc.data_path=='hide_render':
            for k in fc.keyframe_points:k.interpolation='CONSTANT'

s.frame_start=1;s.frame_end=2616;s.frame_set(1)
# An opening camera view makes the downloaded project easier to navigate.
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath)
print('PORTABLE_FINAL_SAVED',flush=True)
