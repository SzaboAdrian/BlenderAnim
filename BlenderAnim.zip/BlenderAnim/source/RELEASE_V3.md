# Melancholy finishing edition

This edition keeps the complete 2,616-frame, 24 fps film and the original 109-second soundtrack. The delivered file is the full movie.

Changes:

- An AgX-to-display conversion followed by a shared blue/lavender grade: reduced saturation, restrained highlights, cool shadows, preserved black. No added film grain.
- Packed alpha artwork on animated chest and back planes of all three instances of Adrian. The print follows the torso and respects geometry occlusion.
- A packed DejaVu Serif Italic closing dedication, appearing smoothly from frames 2269–2341, holding through 2557, and fading through 2616. The wording is exactly: `Maybe in another life, there will be an opportunity, to be more than a dreamer, Adrian`.
- A revised studio face camera that remains on the performer's side of the monitor throughout the push.

Files and workflows:

- `output/bus_stop_to_stage.blend`: standalone native render project. Packed shirt/title images; relative `//final_mix.wav` soundtrack. Native sector visibility, 1280 × 720, EEVEE, 32 samples, 24 fps. Its compositor contains the complete grade and closing title.
- `BlenderAnim_final.mp4`: full 960 × 540 film, H.264/AAC, 109 seconds.
- `output/assets_v3/`: artwork, font files, font license, exact dedication text, and the AgX ink calibration.
- `source/finish_v3.py`: regenerates the packed artwork, shirt planes, grade and closing title. It can run against the supplied finished project, then writes `output/film_render_v3.blend`. Pillow and NumPy are used by the script; they are not required to open or render the supplied `.blend`.
- `source/render_v3.py`: native rendering of the revised studio camera, or selected proof frames.
- `source/finish_cached_v3.py`: production finishing of the previous rendered plates, using the identical grade and camera-projected, raycast-masked shirt print. It needs the production cache `output/final_frames/`, which is omitted from the download to keep its size practical. A full native render of the supplied project does not need this cache.
- `source/assemble_v3.py`: assembles the complete production plates with per-shot optical interpolation from 12 to 24 fps and checks frame count, duration, audio, and full-file decoding.

The base scene and timing scripts from the previous edition are included for reference. The final `.blend` is the starting point for normal editing and rendering; no earlier version is needed. Both PNG artwork files are packed, so reopening on another computer does not rely on this workspace's absolute paths.

Verification includes native Blender proof renders against the finished plates, complete frame coverage, unaltered three-second stage hold, black transitions, packed assets/relative audio, FFprobe stream and duration checks, full FFmpeg decode, and archive integrity.
