"""Baked two-bone limbs, planted-foot walking and eased acting for the animatic."""
import bpy, math
from mathutils import Vector

def smooth(t):
    t=max(0,min(1,t));return t*t*(3-2*t)
def mix(a,b,t):return Vector(a).lerp(Vector(b),t)
def apply_motion(s, rebuild=False):
    if s.get('motion_v1'):
        if not rebuild:return
        for root in [o for o in s.objects if o.type=='EMPTY' and o.get('motion')]:
            for child in list(root.children):
                if any(token in child.name for token in [' upper leg',' lower leg',' shoe',' upper arm',' forearm',' hand']):
                    bpy.data.objects.remove(child,do_unlink=True)
        for o in list(s.objects):
            if o.name.startswith(('Bus dark doorway','Bus boarding step')):bpy.data.objects.remove(o,do_unlink=True)
    s['motion_v1']=True
    def empty(name,parent):
        o=bpy.data.objects.new(name,None);s.collection.objects.link(o);o.parent=parent;return o
    def mesh(name,parent,material,dim):
        x,y,z=[v/2 for v in dim]
        v=[(-x,-y,-z),(-x,-y,z),(-x,y,-z),(-x,y,z),(x,-y,-z),(x,-y,z),(x,y,-z),(x,y,z)]
        d=bpy.data.meshes.new(name);d.from_pydata(v,[],[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)]);d.materials.append(material)
        o=bpy.data.objects.new(name,d);s.collection.objects.link(o);o.parent=parent
        mod=o.modifiers.new('Soft limb edges','BEVEL');mod.width=.04;mod.segments=3
        return o
    def key(o,f,loc=None,rot=None):
        if loc is not None:o.location=loc;o.keyframe_insert('location',frame=f)
        if rot is not None:o.rotation_euler=rot;o.keyframe_insert('rotation_euler',frame=f)
    def bone(o,a,b,f,width):
        a=Vector(a);b=Vector(b);o.location=(a+b)/2;o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();o.scale=(1,1,(b-a).length)
        for p in ['location','rotation_euler','scale']:o.keyframe_insert(p,frame=f)
    def ik(a,b,l1,l2,pole):
        a=Vector(a);b=Vector(b);d=b-a;length=max(.001,min(d.length,l1+l2-.001));axis=d.normalized()
        along=(l1*l1-l2*l2+length*length)/(2*length)
        p=Vector(pole);p=(p-axis*p.dot(axis)).normalized()
        return a+axis*along+p*math.sqrt(max(0,l1*l1-along*along))
    # Walk in world space: each planted foot stays fixed throughout stance.
    def walk(f,start,end,a,b,side,steps):
        t=max(0,min(1,(f-start)/(end-start)));direction=(Vector(b)-Vector(a));direction.z=0;direction.normalize()
        phase=t*steps + (0 if side<0 else .5)
        cycle=math.floor(phase);u=phase-cycle
        offset=0 if side<0 else .5
        # Half-stride cycles stagger left and right support.
        def point(k):
            q=max(0,min(1,(k-offset+.25)/steps));p=mix(a,b,smooth(q))
            lateral=Vector((-direction.y,direction.x,0))*side*.14
            return p+lateral
        if u<.60:p=point(cycle)
        else:
            v=(u-.60)/.40;p=point(cycle).lerp(point(cycle+1),smooth(v));p.z+=.115*math.sin(math.pi*v)
        return p
    roots=[s.objects.get(n) for n in ['Narrator seated','Woman seated','Woman standing','Narrator at computer','Narrator on stage']]
    skin=bpy.data.materials['Portrait warm skin'];dark=bpy.data.materials['Portrait black T shirt'];pants=bpy.data.materials['Clothes dark']
    for root in roots:
        if root is None:continue
        name=root.name;head=next(c for c in root.children if ' head' in c.name)
        # Preserve authored gaze and head shake, then add breathing and anticipation.
        old_head={}
        curves={fc.array_index:fc for fc in head.animation_data.action.fcurves if fc.data_path=='rotation_euler'} if head.animation_data and head.animation_data.action else {}
        for f in range(1,1441):
            r=head.rotation_euler.copy()
            for axis,fc in curves.items():r[axis]=fc.evaluate(f)
            old_head[f]=r
        head.animation_data_clear()
        for child in list(root.children):
            if child.type=='MESH' and any(p in child.name for p in ['Thigh','Shin','Leg']):bpy.data.objects.remove(child,do_unlink=True)
            elif child.type=='EMPTY' and child.name.startswith('Arm pivot'):
                for c in list(child.children):bpy.data.objects.remove(c,do_unlink=True)
                bpy.data.objects.remove(child,do_unlink=True)
        # Keep visibility keys; replace only root trajectory and orientation.
        if root.animation_data and root.animation_data.action:
            for fc in list(root.animation_data.action.fcurves):
                if fc.data_path in ['location','rotation_euler']:root.animation_data.action.fcurves.remove(fc)
        iswoman=name.startswith('Woman');shirt=bpy.data.materials['Woman navy suit'] if iswoman else dark
        limbs={}
        for side in [-1,1]:
            limbs[side]=[mesh(name+' upper leg',root,pants,(.17,.19,1)),mesh(name+' lower leg',root,pants,(.15,.17,1)),mesh(name+' shoe',root,dark,(.18,.30,.10)),mesh(name+' upper arm',root,shirt,(.14,.16,1)),mesh(name+' forearm',root,shirt,(.12,.14,1)),mesh(name+' hand',root,skin,(.09,.07,.13))]
        torso=next(c for c in root.children if 'torso' in c.name)
        for f in sorted(set(range(1,1441,2)) | {312,339,540,564,565,572,632,1128,1200,1440}):
            moving=False;seated=True;rot=0;bob=0;phase=0;feetworld=None;lean=0
            if name=='Narrator seated':
                t=smooth((f-240)/72);pos=mix((5,-.75,.12),(.75,-.75,.12),t)
                if f<312:
                    moving=240<=f<312;rot=(-math.pi/2)*(1-smooth((f-305)/15));phase=(f-240)/72*5*math.tau
                    feetworld={side:walk(f,240,312,(5,-.75,.05),(.75,-.75,.05),side,5) for side in [-1,1]}
                    seated=False
                else:
                    q=smooth((f-312)/27);pos=mix((.75,-.75,.12),(.75,-.3,0),q);rot=(-math.pi/2)*(1-smooth((f-305)/15));seated=q>.5;lean=.18*math.sin(q*math.pi)
                if f>=350:lean=.10
            elif name=='Woman seated':
                q=smooth((f-540)/25);pos=Vector((-.7,-.3,.12*q));seated=True;lean=-.22*math.sin(q*math.pi)
            elif name=='Woman standing':
                # Walk around the shelter instead of through the bench/poster.
                route=[(572,588,(-.7,-.3,.12),(-2.75,-.55,.12),2),
                       (588,611,(-2.75,-.55,.12),(-2.75,1.75,.12),2),
                       (611,629,(-2.75,1.75,.12),(-1,2.05,.12),2),
                       (629,637,(-1,2.05,.12),(-1,2.7,.62),1)]
                seg=next((r for r in route if f<r[1]),route[-1])
                begin,end,a,b,count=seg;t=smooth((f-begin)/(end-begin));pos=mix(a,b,t)
                dx=b[0]-a[0];dy=b[1]-a[1];rot=math.atan2(dx,-dy);seated=False
                idx=route.index(seg)
                if idx<len(route)-1:
                    nxt=route[idx+1];target=math.atan2(nxt[3][0]-nxt[2][0],-(nxt[3][1]-nxt[2][1]))
                    delta=(target-rot+math.pi)%(2*math.pi)-math.pi
                    rot+=delta*smooth((f-(end-5))/5)
                if f<572:rot=(-math.pi/2)*smooth((f-565)/7)
                moving=572<=f<=637;phase=(f-begin)/(end-begin)*count*math.tau
                fa=(a[0],a[1],a[2]-.07);fb=(b[0],b[1],b[2]-.07)
                feetworld={side:walk(f,begin,end,fa,fb,side,count) for side in [-1,1]}
            elif name=='Narrator at computer':pos=Vector((40,-1.05,0));rot=math.pi;lean=.06
            else:
                t=smooth((f-1057)/65);pos=mix((86,0,.82),(80,0,.82),t);rot=-math.pi/2-(math.pi/2)*smooth((f-1110)/18);seated=False
                moving=1057<=f<1122;phase=(f-1057)/65*6*math.tau
                feetworld={side:walk(f,1057,1122,(86,0,.75),(80,0,.75),side,6) for side in [-1,1]}
            if moving:bob=.015*math.cos(phase*2);pos.z+=bob
            key(root,f,pos,(0,0,rot))
            # Use analytic rotation instead of a stale dependency-graph matrix.
            def local(p):
                d=Vector(p)-pos;return Vector((math.cos(rot)*d.x+math.sin(rot)*d.y,-math.sin(rot)*d.x+math.cos(rot)*d.y,d.z))
            frozen=name=='Narrator on stage' and 1128<=f<=1200
            idle=0 if frozen else math.sin(f*.075)*.006
            r=old_head[f];r.x+=idle+lean*.25
            if name=='Woman standing':r.z=-.65*(1-smooth((f-565)/15))
            key(head,f,(0,-.02*lean,1.62+idle),r)
            key(torso,f,(0,0,1.05+idle),(lean,0,.018*math.sin(phase) if moving else 0))
            for side in [-1,1]:
                upper,lower,shoe,arm,fore,hand=limbs[side]
                hip=Vector((side*.14,0,.76))
                foot=local(feetworld[side]) if moving else Vector((side*.14,-.46 if seated else -.03,.05))
                # Continuous lowering into the bench, with both feet planted.
                if name=='Narrator seated' and 312<=f<339:
                    foot=Vector((side*.14,-.46*smooth((f-312)/27),.05-pos.z))
                if name=='Woman seated':foot.z-=pos.z
                if name=='Woman standing' and f<572:foot.y=-.46+.43*smooth((f-565)/7)
                knee=ik(hip,foot,.46,.46,(0,-1,0))
                bone(upper,hip,knee,f,.17);bone(lower,knee,foot,f,.15)
                key(shoe,f,foot+Vector((0,-.07,-.005)),(0,0,0))
                shoulder=Vector((side*.29,0,1.30+idle));target=Vector((side*.30,-.13,.84))
                if moving:target.y+=side*.18*math.sin(phase);target.z+=.035*math.cos(phase)
                elif seated:target=Vector((side*.22,-.32,.83))
                if name=='Narrator seated':
                    cover=smooth((f-341)/20)*(1-smooth((f-508)/25))
                    target=target.lerp(Vector((side*.09,-.21,1.57)),cover)
                    scratch=smooth((f-660)/20)*(1-smooth((f-705)/20)) if side>0 else 0
                    target=target.lerp(Vector((.16,-.015+.018*math.sin(f*.8),1.84)),scratch)
                elif name=='Narrator at computer':
                    # Asymmetric wrists, short taps rather than whole-arm pumping.
                    tap=max(0,math.sin((f-780)*math.tau/36))**8
                    target=Vector((side*.23,-.60,.99-.018*tap))
                elif name=='Woman seated' and 395<f<450 and side>0:
                    q=math.sin((f-395)/55*math.pi);target=target.lerp(Vector((.28,-.39,1.10)),q*.6)
                elbow=ik(shoulder,target,.30,.31,(side,-.2,-.5))
                bone(arm,shoulder,elbow,f,.14);bone(fore,elbow,target,f,.12);key(hand,f,target,(0,0,0))
        for o in [root,head,torso]+[o for group in limbs.values() for o in group]:
            if o.animation_data and o.animation_data.action:
                for fc in o.animation_data.action.fcurves:
                    if fc.data_path!='scale' or o!=root:
                        for p in fc.keyframe_points:p.interpolation='LINEAR'
        root['motion']='Baked two-bone limbs with world-space foot contacts and eased actions'
    # Door opening gives the boarding action a clear destination.
    bus=s.objects.get('Arriving bus')
    if bus:
        mesh('Bus dark doorway',bus,bpy.data.materials['Equipment charcoal'],(.85,.04,2.2)).location=(-1,-1.18,1.4)
        mesh('Bus boarding step',bus,bpy.data.materials['Brushed silver'],(.85,.5,.14)).location=(-1,-1.35,.27)
    s.frame_set(1)
