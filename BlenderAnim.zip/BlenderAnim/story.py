"""Blender 4.3+: run in Scripting > Run Script, or blender -b --python story.py.
Creates a NEW scene, preserving existing scenes. Outputs beside this script.
Stylized animatic; placeholder actors, synthesized guide audio, subtitle dialogue.
"""
import bpy, math, random, wave, struct
from pathlib import Path
from mathutils import Vector
FPS = 24
OUT = Path(__file__).resolve().parent / 'output' if '__file__' in globals() else Path(bpy.path.abspath('//')) / 'output'
OUT.mkdir(parents=True, exist_ok=True)
random.seed(7)
s = bpy.data.scenes.new('Bus Stop to Stage')
bpy.context.window.scene = s
s.render.engine = 'CYCLES'
s.cycles.samples = 16
s.cycles.use_denoising = False
s.render.resolution_x, s.render.resolution_y = 1280, 720
s.render.resolution_percentage = 100
s.render.fps = FPS
s.frame_start, s.frame_end = 1, 1440
s.world = bpy.data.worlds.new('Evening world')
s.world.use_nodes = True
s.world.node_tree.nodes['Background'].inputs[0].default_value = (.065,.075,.12,1)
s.world.node_tree.nodes['Background'].inputs[1].default_value = .35

def mat(name, color, emission=0):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF'); p.inputs['Base Color'].default_value=(*color,1)
    if emission:
        p.inputs['Emission Color'].default_value=(*color,1); p.inputs['Emission Strength'].default_value=emission
    return m
skin=mat('Skin',(.65,.38,.23)); dark=mat('Clothes dark',(.025,.035,.06)); purple=mat('Her coat',(.35,.1,.3))
wood=mat('Bench',(.24,.12,.055)); metal=mat('Metal',(.12,.15,.18)); ground=mat('Pavement',(.22,.24,.25))
black=mat('Acoustic foam',(.018,.015,.025)); led=mat('Violet LED',(.45,.025,1),5); white=mat('Text',(.95,.95,.95),1)

def cube(name, loc, size, material, parent=None):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc); o=bpy.context.object; o.name=name
    o.dimensions=size; bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    o.data.materials.append(material); o.parent=parent; return o

def ball(name, loc, scale, material, parent=None):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=12,ring_count=8,radius=1,location=loc)
    o=bpy.context.object; o.name=name; o.scale=scale; o.data.materials.append(material); o.parent=parent; return o

def empty(name,loc):
    o=bpy.data.objects.new(name,None); s.collection.objects.link(o); o.location=loc; return o

def key(o,f,loc=None,rot=None):
    if loc is not None: o.location=loc; o.keyframe_insert('location',frame=f)
    if rot is not None: o.rotation_euler=rot; o.keyframe_insert('rotation_euler',frame=f)

def actor(name,loc,coat,seated=False):
    root=empty(name,loc)
    cube(name+' torso',(0,0,1.05),(.48,.28,.65),coat,root)
    head=empty(name+' head',(0,0,1.62)); head.parent=root
    ball('Head',(0,0,0),(.20,.18,.24),skin,head)
    for x in [-.075,.075]: ball('Eye',(x,-.168,.04),(.018,.012,.018),dark,head)
    # A small curved smile, visible in the close-up.
    curve=bpy.data.curves.new('Smile','CURVE'); curve.dimensions='3D'; curve.bevel_depth=.009; curve.bevel_resolution=2
    sp=curve.splines.new('POLY'); sp.points.add(8)
    for i,p in enumerate(sp.points):
        x=(i-4)*.018; p.co=(x,-.177,-.09+2*x*x,1)
    ob=bpy.data.objects.new('Gentle smile',curve); s.collection.objects.link(ob); ob.parent=head; ob.data.materials.append(dark)
    hands=[]
    for x in [-.30,.30]:
        pivot=empty('Arm pivot',(x,0,1.30)); pivot.parent=root
        cube('Sleeve',(0,0,-.21),(.14,.17,.43),coat,pivot)
        ball('Hand',(0,0,-.47),(.085,.075,.10),skin,pivot); hands.append(pivot)
    for x in [-.14,.14]:
        if seated:
            cube('Thigh',(x,-.22,.72),(.18,.56,.18),dark,root)
            cube('Shin',(x,-.44,.38),(.17,.18,.64),dark,root)
        else: cube('Leg',(x,0,.39),(.18,.22,.78),dark,root)
    return root,head,hands

def light(name,loc,color,power,size=5):
    d=bpy.data.lights.new(name,'AREA'); d.energy=power; d.color=color; d.shape='DISK'; d.size=size
    o=bpy.data.objects.new(name,d); s.collection.objects.link(o); o.location=loc; return o

def camera(name,start,end,a,b,target_a,target_b,lens=48):
    d=bpy.data.cameras.new(name); d.lens=lens; o=bpy.data.objects.new(name,d); s.collection.objects.link(o)
    for f,pos,target in [(start,a,target_a),(end,b,target_b)]:
        key(o,f,pos,(Vector(target)-Vector(pos)).to_track_quat('-Z','Y').to_euler())
    marker=s.timeline_markers.new(name,frame=start); marker.camera=o
    if s.camera is None:s.camera=o
    return o

# Stop: actors face towards negative Y, road behind the bench.
cube('Street',(0,3,-.12),(30,5,.2),metal)
cube('Sidewalk',(0,0,-.1),(30,4,.2),ground)
cube('Bench seat',(0,0,.65),(3.4,.65,.16),wood)
cube('Bench back',(0,.27,1.15),(3.4,.12,.75),wood)
for x in [-1.4,1.4]: cube('Bench support',(x,0,.3),(.12,.5,.6),metal)
for x in [-2.2,2.2]: cube('Shelter post',(x,.7,1.5),(.12,.12,3),metal)
cube('Shelter roof',(0,.3,3),(5,2,.15),metal)
cube('Bus stop sign',(2.8,.2,2.5),(.65,.15,.75),purple)
light('Stop softbox',(0,-3,6),(1,.77,.58),1000)
her,hh,ha=actor('Woman seated',(-.7,-.3,0),purple,True)
me,mh,ma=actor('Narrator seated',(.75,-.3,0),dark,True)
# Walk into the wide shot, then lower into the sitting pose (stylized blocking).
key(me,1,(5,-.3,.35));key(me,240,(5,-.3,.35));key(me,310,(.75,-.3,.35));key(me,336,(.75,-.3,0))
key(hh,120,rot=(0,0,0));key(hh,175,rot=(0,0,-.35));key(hh,360,rot=(0,0,-.35));key(hh,410,rot=(0,0,-.65))
for arm,sign in zip(ma,[-1,1]):
    key(arm,330,rot=(0,0,0)); key(arm,360,rot=(-2.15,sign*.35,0));key(arm,500,rot=(-2.15,sign*.35,0));key(arm,535,rot=(0,0,0))
for f,z in [(470,0),(482,.3),(494,-.3),(506,.2),(518,0)]: key(mh,f,rot=(.15,0,z))
# A separate standing double appears when she gets up; scale switches hide the seated double.
standing,sh,sa=actor('Woman standing',(-.7,-.3,0),purple)
for o,vals in [(her,[(1,1),(564,1),(565,0)]),(standing,[(1,0),(564,0),(565,1),(637,1),(638,0)])]:
    for f,v in vals:o.scale=(v,)*3;o.keyframe_insert('scale',frame=f)
    for fc in o.animation_data.action.fcurves:
        if fc.data_path=='scale':
            for kp in fc.keyframe_points:kp.interpolation='CONSTANT'
key(standing,565,(-.7,-.3,0));key(standing,605,(-1,2,0));key(standing,637,(-1,3.2,.5))
bus=empty('Arriving bus',(17,3.5,0))
cube('Bus body',(0,0,1.5),(7,2.3,2.6),purple,bus)
for x in [-2.4,-1.2,0,1.2,2.4]:cube('Bus window',(x,-1.17,2.1),(.9,.04,.8),metal,bus)
for x in [-2.2,2.2]:ball('Wheel',(x,-1.1,.45),(.5,.2,.5),dark,bus)
key(bus,1,(17,3.5,0));key(bus,510,(17,3.5,0));key(bus,564,(0,3.5,0));key(bus,650,(0,3.5,0));key(bus,720,(-18,3.5,0))
for f,r in [(650,(0,0,0)),(678,(-2.6,0,-.3)),(690,(-2.6,.15,-.3)),(702,(-2.6,-.15,-.3)),(720,(0,0,0))]:key(ma[1],f,rot=r)
camera('01 Wide stop push in',1,144,(9,-13,6),(1,-4,2.1),(0,0,1),(-.7,-.3,1.5))
camera('02 She notices you',145,239,(-.3,-2.1,1.8),(-.4,-1.8,1.8),(-.7,-.3,1.65),(-.7,-.3,1.65),65)
camera('03 You sit down',240,359,(4,-7,3),(3,-6,2.8),(0,0,1),(0,0,1))
camera('04 Are you fine',360,469,(1.8,-3,1.9),(1.4,-2.8,1.9),(-.5,-.3,1.5),(-.5,-.3,1.5))
camera('05 No I am not',470,529,(1,-2,1.8),(1,-1.8,1.8),(.75,-.3,1.6),(.75,-.3,1.6),65)
camera('06 Bus and goodbye',530,649,(7,-8,4),(6,-7,3.5),(0,1,1),(0,1,1),35)
camera('07 Alone thinking',650,744,(3,-5,2.4),(1,-1.9,1.85),(.75,-.3,1.5),(.75,-.3,1.6))
# Studio, separated spatially from the stop.
cube('Studio floor',(40,0,-.1),(12,10,.2),dark)
cube('Studio back wall',(40,2,2.3),(12,.2,4.6),metal)
for x in range(36,45,2):cube('Acoustic panel',(x,1.83,2.5),(1.3,.2,2),black)
cube('LED strip',(40,1.65,3.9),(10,.06,.05),led)
cube('Desk',(40,0,.85),(3,1.2,.15),wood)
cube('Monitor',(40,.4,1.6),(1.3,.12,.8),black)
cube('Screen',(40,.325,1.6),(1.15,.02,.65),led)
cube('Keyboard',(40,-.3,.97),(1.1,.35,.05),metal)
cube('Spacebar',(40,-.43,1.01),(.45,.06,.03),white)
producer,ph,pa=actor('Narrator at computer',(40,-1.05,0),dark,True)
producer.rotation_euler.z=math.pi
for arm in pa:
    for f in [745,780,816,852,888,924,960,996,1032]:
        key(arm,f,rot=(-1.1,0,0));key(arm,f+5,rot=(-1.35,0,0));key(arm,f+10,rot=(-1.1,0,0))
light('Studio violet',(40,-1,4),(.5,.08,1),500)
light('Studio face',(40,1,3),(.4,.6,1),200)
camera('08 Studio side typing',745,930,(44,-3,2.7),(43,-2.5,2.3),(40,-.4,1.3),(40,-.4,1.3))
camera('09 Studio face push',931,1056,(43,1,2.3),(40.9,.5,1.8),(40,-1.05,1.6),(40,-1.05,1.6),60)
# Concert. Camera sees the performer's back and the audience beyond the stage.
cube('Stage',(80,0,.35),(12,7,.7),black)
performer,eh,ea=actor('Narrator on stage',(86,0,.7),dark)
performer.rotation_euler.z=math.pi
key(performer,1057,(86,0,.7));key(performer,1128,(80,0,.7));key(performer,1200,(80,0,.7))
cube('Audience ground',(80,17,-.15),(50,35,.2),ground)
for i in range(250):
    x=80+random.uniform(-22,22);y=random.uniform(5,33)
    r=empty('Cheering fan',(x,y,0));ball('Fan head',(0,0,1.55),(.19,.18,.22),skin,r)
    cube('Fan torso',(0,0,1),(.42,.28,.75),purple if i%3 else dark,r)
    for side in [-1,1]:
        arm=cube('Raised arm',(side*.32,0,1.55),(.13,.14,.8),skin,r)
        for f in [1057,1090,1128,1200,1240,1300,1370,1440]:
            # 1128–1200 is an actual still hold, including the crowd.
            z=side*.32 if f in [1128,1200] else side*random.uniform(.2,.8)
            key(arm,f,rot=(0,z,0))
for x in [75,85]:light('Stage violet',(x,-2,6),(.5,.08,1),1800)
light('Audience wash',(80,14,9),(.4,.5,1),4000,20)
camera('10 Walk on stage and freeze',1057,1200,(80,-7,3),(80,-7,3),(80,9,1.5),(80,9,1.5),32)
camera('11 Drone pull away',1201,1440,(80,-9,7),(80,-40,42),(80,9,0),(80,12,0),28)
# Subtitles attached to the relevant cameras.
def subtitle(cam,body,start,end):
    d=bpy.data.curves.new('Subtitle','FONT');d.body=body;d.align_x='CENTER';d.size=.065
    o=bpy.data.objects.new(body,d);s.collection.objects.link(o);o.parent=cam;o.location=(0,-.36,-2);d.materials.append(white)
    for f,v in [(1,0),(start,1),(end,1),(end+1,0)]:o.scale=(v,)*3;o.keyframe_insert('scale',frame=f)
    for fc in o.animation_data.action.fcurves:
        for kp in fc.keyframe_points:kp.interpolation='CONSTANT'
subtitle(s.timeline_markers['04 Are you fine'].camera,'Hey! Are you really fine?',395,469)
subtitle(s.timeline_markers['05 No I am not'].camera,"No, I'm not...",478,529)
# Real black transition between stop and studio using the compositor.
s.use_nodes=True;n=s.node_tree.nodes;n.clear();rl=n.new('CompositorNodeRLayers');rl.scene=s
mix=n.new('CompositorNodeMixRGB');mix.blend_type='MULTIPLY';mix.inputs[0].default_value=1
s.node_tree.links.new(rl.outputs['Image'],mix.inputs[1]);out=n.new('CompositorNodeComposite');s.node_tree.links.new(mix.outputs[0],out.inputs[0])
for f,v in [(1,1),(720,1),(744,0),(745,0),(768,1),(1416,1),(1440,0)]:
    mix.inputs[2].default_value=(v,v,v,1);mix.inputs[2].keyframe_insert('default_value',frame=f)
# Synthesized guide sounds, no downloaded assets or spoken voice imitation.
def sound(name,duration,fn):
    path=OUT/(name+'.wav');rate=22050
    with wave.open(str(path),'wb') as w:
        w.setparams((1,2,rate,0,'NONE','not compressed'))
        w.writeframes(b''.join(struct.pack('<h',int(max(-1,min(1,fn(i/rate)))*24000)) for i in range(int(duration*rate))))
    return path
buswav=sound('bus_guide',7,lambda t:.18*math.sin(2*math.pi*(65*t+2*t*t))*(min(t,1))*min(1,(7-t)))
beat=sound('beat_guide',13,lambda t:.5*math.sin(2*math.pi*55*t)*math.exp(-((t% .5)*22))+.08*random.uniform(-1,1)*math.exp(-((t%.25)*65)))
crowd=sound('crowd_guide',16,lambda t:.12*random.uniform(-1,1)*(1+.4*math.sin(t*3)))
seq=s.sequence_editor_create()
for name,path,frame in [('Bus',buswav,510),('Beat',beat,780),('Crowd',crowd,1057)]:seq.sequences.new_sound(name,str(path),channel=1,frame_start=frame)
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from character import replace_narrators
replace_narrators(s)
from environments import enrich
enrich(s)
from motion import apply_motion
apply_motion(s)
s.render.image_settings.file_format='PNG';s.render.filepath=str(OUT/'frame_')
s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'bus_stop_to_stage.blend'))
print('STORY_READY',s.frame_end,'frames;',len(s.objects),'objects;',len(s.timeline_markers),'shots')
