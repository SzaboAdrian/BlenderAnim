# Bus Stop to Stage — Blender animatik

`story.py` je samostatný skript pre Blender 4.3+. Vytvorí novú scénu bez mazania existujúcich scén. Používa zástupné postavy a procedurálne objekty; nejde o finálnu realistickú animáciu ani hotový rig pre dodaný charakter.

## Spustenie

V Blenderi otvor **Scripting → Open → story.py → Run Script**. Ulož si najprv vlastnú prácu: skript uloží celý otvorený projekt do `output/bus_stop_to_stage.blend`. Pri spustení z Text Editora bez dostupnej cesty skriptu sa použije adresár aktuálneho Blender projektu.

Z terminálu:

```sh
blender -b --threads 4 --python story.py
blender -b output/bus_stop_to_stage.blend --threads 4 -f 180
```

Projekt má 24 fps, 1440 snímok (60 sekúnd), 1280 × 720. Kláves Num0 zobrazí kameru; časová os obsahuje pomenované strihy. Render Animation vytvorí PNG sekvenciu; zvuk je vo Video Sequence Editore, pri exporte videa vyber FFmpeg Video, MPEG-4, H.264 a AAC. Audio sú iba syntetické orientačné zvuky, dialóg je v titulkoch. Hovorené repliky a finálnu hudbu treba doplniť.

## Zábery

| Snímky | Obsah |
|---|---|
| 1–144 | Veľký celok zastávky, približovanie |
| 145–239 | Detail ženy, všimne si príchod |
| 240–359 | Celok, prisadnutie, zakrytie tváre |
| 360–469 | Otázka: Hey! Are you really fine? |
| 470–529 | Odpoveď: No, I'm not... a pohyb hlavy |
| 530–649 | Autobus, žena vstáva a nastupuje |
| 650–744 | Priblíženie, zamyslenie a poškriabanie hlavy, stmavenie |
| 745–930 | Bočný pohľad v štúdiu, klávesnica, beat |
| 931–1056 | Priblíženie na tvár |
| 1057–1200 | Príchod sprava na pódium, chrbát k divákovi; 1128–1200 zmrazenie |
| 1201–1440 | Dronový odlet od pódia a davu |

Po dodaní charakteru bude potrebné prispôsobiť mierku, rig, pózy a kontakty rúk. Chôdza a nastupovanie sú zatiaľ blokované posunom postáv; autobus, mimika, štúdio aj dav sú zjednodušené. Skript vytvára nové dátové bloky pri každom spustení, preto ho opakuj v čerstvom súbore, ak nechceš viac kópií scény. Generované výstupy sa nachádzajú v `output/`.

## Postava podľa fotografie

`character.py` vytvára štylizovanú podobu hlavnej postavy podľa dodaného portrétu: oválnu tvár, tmavohnedú ofinu, obočie, hnedé oči, nos a prirodzené pery. Profil a telo sú odhadnuté; model nie je fotorealistický sken. `story.py` tento modul automaticky použije na všetky tri výskyty rozprávača. Oba súbory ponechaj v rovnakom adresári. Projekt v `output/bus_stop_to_stage.blend` už obsahuje nový model a nepotrebuje skript na otvorenie.

`update_character.py` obnoví podobu v existujúcom projekte a vytvorí detailný náhľad. Spustenie: `blender -b output/bus_stop_to_stage.blend --threads 4 --python update_character.py`. Pred prepísaním si ulož vlastnú verziu projektu. Náhľad má dočasne upravenú kameru; táto úprava sa do projektu neukladá.

## Prostredia podľa referencií

`environments.py` dopĺňa striebornú zastávku s oblúkovou strechou a drevenou lavicou, stromy a kríky, ženu s dlhými hnedými vlasmi v tmavomodrom kostýme a bielej blúzke, štúdio s reproduktormi, MIDI klávesnicou a padmi a festivalovú konštrukciu s LED stenami, svetlami, PA systémom a 900 divákmi. Ide o vlastné procedurálne 3D interpretácie, nie o vložené fotografie alebo presné kópie referencií.

Pre vytvorenie celého projektu ponechaj `story.py`, `character.py` a `environments.py` v rovnakom adresári. `update_scenery.py` dopĺňa prostredia do staršej verzie projektu; opakované pridávanie blokuje značka v scéne. Náhľady zastávky, dievčaťa, štúdia a koncertu sú uložené v `output/`. Finálny film ešte nie je vyrenderovaný; pracovné pózy, chôdza, výrazy a zvuk ostávajú v kvalite animatiku.

## Pohyb a chôdza

`motion.py` nahrádza pevné končatiny všetkých piatich hereckých objektov dvojsegmentovými nohami a rukami. Chodidlá majú pri chôdzi svetové kontaktné body, strieda sa oporná a švihová fáza, kolená a lakte sa riešia geometricky. Animácia obsahuje protiľahlý pohyb rúk, mierny pohyb trupu, otáčanie pred sadnutím, postupné sadanie a vstávanie, kroky do autobusu a na pódium, zakrytie tváre, poškriabanie hlavy a asymetrické ťukanie do klávesnice. Kľúčové pózy sa ukladajú každé dve snímky a na hraniciach akcií. Koncertné zmrazenie je zachované.

`story.py` automaticky spustí `motion.py` po vytvorení postáv a prostredí; všetky štyri moduly nechaj spolu. Pre aktualizáciu existujúceho projektu: `blender -b output/bus_stop_to_stage.blend --threads 4 --python update_motion.py`. Táto operácia prepíše animácie hlavných postáv, preto si vlastné úpravy najskôr zálohuj. `verify_motion.py` overí oporné chodidlo, prítomnosť pohybu u všetkých postáv a koncertné zmrazenie a vytvorí náhľad sekvencie príchodu.

Pohyb je podstatne prepracovanejší než pôvodný posun pevných postáv, ale stále ide o procedurálny animatik: bez motion capture, prstového rigu, svalových deformácií a simulácie kontaktov. Geometria oblečenia a tvár zostávajú štylizované.
