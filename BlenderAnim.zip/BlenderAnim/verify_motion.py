import bpy
from pathlib import Path
s=bpy.context.scene
root=s.objects['Narrator seated']
shoes=[o for o in root.children if ' shoe' in o.name]
assert len(shoes)==2
shoe=shoes[0]
positions=[]
for f in [261,263]:
    s.frame_set(f);positions.append(shoe.matrix_world.translation.copy())
slip=(positions[1]-positions[0]).length
print('STANCE_DRIFT_METERS',slip)
assert slip<.005,slip
for name in ['Narrator seated','Woman seated','Woman standing','Narrator at computer','Narrator on stage']:
    o=s.objects[name];assert o['motion'];assert len([c for c in o.children if 'upper leg' in c.name])==2
# The intentional concert freeze must hold the entire hero, not just the root.
p=s.objects['Narrator on stage'];children=list(p.children)
s.frame_set(1140);a={o.name:o.matrix_world.copy() for o in children}
s.frame_set(1180)
assert all(max(abs(o.matrix_world[i][j]-a[o.name][i][j]) for i in range(4) for j in range(4))<1e-5 for o in children)
from mathutils import Vector
for name,f in [('Narrator seated',270),('Woman standing',580),('Narrator on stage',1080)]:
    o=s.objects[name]
    s.frame_set(f);a=o.matrix_world.translation.copy();front=o.matrix_world.to_quaternion() @ Vector((0,-1,0))
    s.frame_set(f+1);delta=o.matrix_world.translation-a;delta.z=0
    alignment=front.normalized().dot(delta.normalized())
    assert alignment>.95,(name,alignment)
    print('FORWARD_WALK',name,round(alignment,4))
print('FIVE_ACTORS_AND_FREEZE_OK')
s.render.resolution_percentage=25;s.cycles.samples=4
s.render.filepath=str(Path(bpy.data.filepath).parent/'motion_frames'/'walk_')
s.frame_start=240;s.frame_end=338;s.frame_step=2
bpy.ops.render.render(animation=True)
print('WALK_PREVIEW_RENDERED')
