import bpy,sys
from pathlib import Path
BASE=Path(__file__).resolve().parent;sys.path.insert(0,str(BASE))
from motion import apply_motion
s=bpy.context.scene
apply_motion(s, rebuild=True)
bpy.ops.wm.save_as_mainfile(filepath=str(BASE/'output/bus_stop_to_stage.blend'))
for f,name in [(278,'walk_motion'),(325,'sit_motion'),(598,'boarding_motion'),(820,'typing_motion'),(1095,'stage_walk_motion')]:
    s.frame_set(f);s.render.resolution_percentage=40;s.cycles.samples=12
    s.render.filepath=str(BASE/'output'/f'{name}.png');bpy.ops.render.render(write_still=True)
print('MOTION_READY')
