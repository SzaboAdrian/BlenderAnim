"""Procedural stylized likeness from the supplied front photo. Blender 4.3+."""
import bpy, math, random
from mathutils import Vector

def material(name,color,rough=.5):
    m=bpy.data.materials.get(name) or bpy.data.materials.new(name)
    m.diffuse_color=(*color,1);m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*color,1);p.inputs['Roughness'].default_value=rough
    return m

def likeness(head):
    """Attach face and hair to an existing animated head pivot (front = -Y)."""
    rng=random.Random(31)
    skin=material('Portrait warm skin',(.52,.32,.225),.58)
    hair=material('Portrait dark brown hair',(.047,.026,.018),.65)
    streak=material('Portrait hair highlights',(.085,.047,.029),.6)
    brows=material('Portrait eyebrows',(.035,.018,.012),.8)
    lips=material('Portrait natural lips',(.37,.155,.135),.65)
    eyes=material('Portrait eyes ivory',(.72,.66,.59),.35)
    iris=material('Portrait brown iris',(.06,.028,.015),.28)
    pupil=material('Portrait pupil',(.006,.004,.003),.25)
    def mesh(name,verts,faces,mat):
        d=bpy.data.meshes.new(name);d.from_pydata(verts,[],faces);d.update()
        o=bpy.data.objects.new(name,d);bpy.context.scene.collection.objects.link(o);o.parent=head;d.materials.append(mat)
        for p in d.polygons:p.use_smooth=True
        return o
    def ell(name,loc,scale,mat):
        # Build without operators, avoiding dependency-graph rebuilds for each feature.
        verts=[];faces=[];N=32;R=20
        for j in range(R+1):
            phi=math.pi*j/R
            for i in range(N):
                a=2*math.pi*i/N
                verts.append((loc[0]+scale[0]*math.sin(phi)*math.cos(a),loc[1]+scale[1]*math.sin(phi)*math.sin(a),loc[2]+scale[2]*math.cos(phi)))
        for j in range(R):
            for i in range(N):
                a=j*N+i;b=j*N+(i+1)%N;faces.append((a,b,b+N,a+N))
        return mesh(name,verts,faces,mat)
    def line(name,points,width,mat):
        d=bpy.data.curves.new(name,'CURVE');d.dimensions='3D';d.bevel_depth=width;d.bevel_resolution=3
        sp=d.splines.new('BEZIER');sp.bezier_points.add(len(points)-1)
        for p,co in zip(sp.bezier_points,points):p.co=co;p.handle_left_type='AUTO';p.handle_right_type='AUTO'
        o=bpy.data.objects.new(name,d);bpy.context.scene.collection.objects.link(o);o.parent=head;d.materials.append(mat);return o
    # Oval face with narrower jaw and softly squared chin.
    rings=[(-.255,.066,.085,.004),(-.23,.115,.117,0),(-.18,.151,.142,0),(-.10,.181,.155,.004),(0,.192,.166,.008),(.1,.191,.168,.012),(.19,.176,.157,.018),(.25,.125,.122,.022),(.275,.025,.035,.022)]
    verts=[];faces=[];N=48
    for z,rx,ry,cy in rings:
        for i in range(N):
            a=i*math.tau/N;verts.append((rx*math.cos(a),cy+ry*math.sin(a),z))
    for j in range(len(rings)-1):
        for i in range(N):a=j*N+i;b=j*N+(i+1)%N;faces.append((a,b,b+N,a+N))
    faces.extend([tuple(reversed(range(N))),tuple((len(rings)-1)*N+i for i in range(N))])
    face=mesh('Portrait oval face and jaw',verts,faces,skin)
    mod=face.modifiers.new('Soft facial surface','SUBSURF');mod.levels=2
    ell('Neck',(0,.025,-.30),(.085,.08,.12),skin)
    for side in [-1,1]:
        ell('Ear',(side*.19,.005,-.015),(.035,.025,.065),skin)
        x=side*.077
        ell('Eye almond',(x,-.150,.028),(.047,.022,.025),eyes)
        ell('Brown iris',(x,-.171,.028),(.021,.006,.022),iris)
        ell('Pupil',(x,-.177,.028),(.010,.003,.014),pupil)
        ell('Eye catchlight',(x-.006,-.180,.036),(.003,.002,.004),eyes)
        line('Upper eyelid',[(x-.044,-.16,.03),(x,-.177,.052),(x+.044,-.16,.033)],.005,skin)
        line('Lower eyelid',[(x-.042,-.159,.024),(x,-.173,.005),(x+.041,-.16,.025)],.0035,skin)
        line('Thick straight eyebrow',[(side*.025,-.167,.092),(side*.07,-.165,.105),(side*.115,-.151,.097),(side*.14,-.133,.084)],.010,brows)
    ell('Nose bridge',(0,-.16,-.012),(.024,.032,.070),skin)
    ell('Nose tip',(0,-.199,-.058),(.039,.035,.029),skin)
    for side in [-1,1]:
        ell('Nose wing',(side*.03,-.183,-.064),(.022,.022,.019),skin)
        ell('Nostril',(side*.025,-.202,-.075),(.009,.006,.006),brows)
    line('Upper lip',[(-.061,-.147,-.157),(-.027,-.165,-.149),(0,-.17,-.154),(.026,-.165,-.149),(.061,-.147,-.157)],.008,lips)
    line('Lower lip',[(-.054,-.15,-.16),(0,-.173,-.177),(.054,-.15,-.16)],.010,lips)
    line('Closed mouth',[(-.057,-.157,-.158),(0,-.177,-.159),(.057,-.157,-.158)],.0025,brows)
    # Hair cap is an upper hemisphere; separate tapered locks form the fringe.
    verts=[];faces=[];N=64;R=16
    for j in range(R+1):
        for i in range(N):
            a=math.tau*i/N
            # Higher hairline at front, lower at back and temples.
            end=1.65+.45*math.sin(a)
            phi=.015+(end-.015)*j/R
            verts.append((.208*math.sin(phi)*math.cos(a),.025+.182*math.sin(phi)*math.sin(a),.045+.268*math.cos(phi)))
    for j in range(R):
        for i in range(N):a=j*N+i;b=j*N+(i+1)%N;faces.append((a,b,b+N,a+N))
    mesh('Full brown hair cap',verts,faces,hair)
    for i in range(19):
        x=-.183+i*.020
        tipz=.105+.025*math.sin(i*1.8)+.05*abs(x)/.19
        lock=ell('Layered fringe',(x,-.131,.205-.035*abs(x)/.19),(.029,.047,.065),hair)
        lock.rotation_euler.y=-x*1.4
        line('Fringe strand',[(x*.7,-.085,.284),(x,-.166,.22),(x+.009,-.177,tipz)],.006,streak if i%3==0 else hair)
    for i in range(65):
        a=rng.uniform(0,math.tau);end=1.65+.45*math.sin(a)
        points=[]
        for k in range(7):
            phi=.12+(end-.18)*k/6;aa=a+.1*math.sin(phi)
            points.append((.211*math.sin(phi)*math.cos(aa),.025+.185*math.sin(phi)*math.sin(aa),.045+.271*math.cos(phi)))
        line('Combed hair strand',points,.0016,streak if i%4==0 else hair)
    head['reference']='Stylized likeness from user supplied front portrait; inferred profile.'


def replace_narrators(scene):
    for root in [o for o in scene.objects if o.type=='EMPTY' and o.name.startswith('Narrator') and ' head' not in o.name]:
        if root.name.startswith('Narrator') and root.type=='EMPTY' and ' head' not in root.name:
            head=next((c for c in root.children if c.type=='EMPTY' and ' head' in c.name),None)
            if head is None:continue
            for child in list(head.children):bpy.data.objects.remove(child,do_unlink=True)
            likeness(head)
            torso=next((c for c in root.children if 'torso' in c.name),None)
            if torso:
                torso.data.materials.clear();torso.data.materials.append(material('Portrait black T shirt',(.013,.016,.021),.9))
                bevel=torso.modifiers.new('Rounded shirt seams','BEVEL');bevel.width=.065;bevel.segments=3
            root['character']='Photo inspired narrator'
