"""Reference-inspired procedural scenery for Blender 4.3. No external assets."""
import bpy, math, random
from mathutils import Vector
from character import material

def enrich(scene):
    if scene.get('reference_scenery_v1'):return
    scene['reference_scenery_v1']=True
    narrator=scene.objects.get('Narrator seated')
    if narrator:
        for f,v in [(1,0),(239,0),(240,1)]:
            narrator.scale=(v,)*3;narrator.keyframe_insert('scale',frame=f)
        for fc in narrator.animation_data.action.fcurves:
            if fc.data_path=='scale':
                for point in fc.keyframe_points:point.interpolation='CONSTANT'
    rng=random.Random(42)
    steel=material('Brushed silver',(.38,.43,.46),.24)
    steel.node_tree.nodes.get('Principled BSDF').inputs['Metallic'].default_value=.8
    timber=material('Warm bench slats',(.26,.105,.038))
    green=material('Meadow',(.075,.16,.045));leaf=material('Tree foliage',(.055,.17,.055));bark=material('Bark',(.13,.065,.025))
    navy=material('Woman navy suit',(.012,.022,.043),.8); blouse=material('Woman ivory blouse',(.8,.79,.72),.8)
    hair=material('Woman chestnut hair',(.075,.037,.019),.7);skin=material('Woman warm skin',(.63,.39,.27),.65)
    ink=material('Woman eyes',(.035,.023,.016));lip=material('Woman lips',(.38,.13,.12))
    black=material('Equipment charcoal',(.012,.015,.022),.8)
    violet=material('Violet practical lights',(.35,.02,1));pink=material('Pink practical lights',(.9,.04,.3))
    for m in [violet,pink]:
        p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Emission Color'].default_value=m.diffuse_color;p.inputs['Emission Strength'].default_value=5
    screen=material('DAW screen background',(.025,.045,.055),.6)
    cyan=material('DAW cyan tracks',(.03,.6,.65));amber=material('DAW orange tracks',(.9,.35,.04))
    def obj(name,verts,faces,mat,parent=None):
        d=bpy.data.meshes.new(name);d.from_pydata(verts,[],faces);d.update();o=bpy.data.objects.new(name,d);scene.collection.objects.link(o);o.parent=parent;d.materials.append(mat);return o
    def box(name,loc,dim,mat,parent=None):
        verts=[(x*dim[0]/2,y*dim[1]/2,z*dim[2]/2) for x,y,z in [(-1,-1,-1),(-1,-1,1),(-1,1,-1),(-1,1,1),(1,-1,-1),(1,-1,1),(1,1,-1),(1,1,1)]]
        o=obj(name,verts,[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)],mat,parent);o.location=loc;return o
    def ell(name,loc,scale,mat,parent=None):
        N=16;R=10;v=[];faces=[]
        for j in range(R+1):
            t=math.pi*j/R
            for i in range(N):
                a=math.tau*i/N;v.append((scale[0]*math.sin(t)*math.cos(a),scale[1]*math.sin(t)*math.sin(a),scale[2]*math.cos(t)))
        for j in range(R):
            for i in range(N):a=j*N+i;b=j*N+(i+1)%N;faces.append((a,b,b+N,a+N))
        o=obj(name,v,faces,mat,parent);o.location=loc
        for p in o.data.polygons:p.use_smooth=True
        return o
    def rod(name,a,b,r,mat,parent=None):
        a=Vector(a);b=Vector(b);v=[];faces=[];N=8
        for z in [0,(b-a).length]:
            for i in range(N):v.append((r*math.cos(math.tau*i/N),r*math.sin(math.tau*i/N),z))
        for i in range(N):j=(i+1)%N;faces.append((i,j,j+N,i+N))
        faces.extend([tuple(reversed(range(N))),tuple(range(N,N*2))])
        o=obj(name,v,faces,mat,parent);o.location=a;o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler();return o
    def text(body,loc,size,mat,rot=(math.pi/2,0,0)):
        d=bpy.data.curves.new(body,'FONT');d.body=body;d.align_x='CENTER';d.size=size
        o=bpy.data.objects.new(body,d);scene.collection.objects.link(o);o.location=loc;o.rotation_euler=rot;d.materials.append(mat);return o
    def remove(prefixes):
        for o in list(scene.objects):
            if any(o.name.startswith(p) for p in prefixes):bpy.data.objects.remove(o,do_unlink=True)
    remove(['Shelter roof','Shelter post','Bench seat','Bench back','Bench support'])
    # Polished shelter frame and an arched, lightly translucent canopy.
    glass=material('Shelter polycarbonate',(.45,.57,.62),.25)
    p=glass.node_tree.nodes.get('Principled BSDF');p.inputs['Transmission Weight'].default_value=.55
    for x in [-2.2,2.2]:
        rod('Silver shelter pillar',(x,.65,0),(x,.65,2.9),.075,steel)
        for y in [-.7,1.2]:rod('Roof cross rail',(-2.5,y,2.95),(2.5,y,2.95),.04,steel)
    for x in [-2.45,-1.6,-.8,0,.8,1.6,2.45]:
        points=[(x,-.85+i*.11,2.94+.32*math.sin(math.pi*i/20)) for i in range(21)]
        for a,b in zip(points,points[1:]):rod('Curved roof rib',a,b,.025,steel)
    v=[]
    for x in [-2.5,2.5]:
        for i in range(21):v.append((x,-.85+i*.11,2.94+.32*math.sin(math.pi*i/20)))
    obj('Arched shelter canopy',v,[(i,i+1,i+22,i+21) for i in range(20)],glass)
    for z in [1.47,2.75]:rod('Poster frame',(-1.98,.69,z),(1.98,.69,z),.045,steel)
    for x in [-1.98,1.98]:rod('Poster upright',(x,.69,1.47),(x,.69,2.75),.045,steel)
    box('Shelter poster backing',(0,.72,2.11),(3.9,.05,1.2),blouse)
    text('BUS  /  24',(0,.675,2.1),.23,navy)
    for y in [-.25,-.09,.07,.23]:box('Bench seat slat',(0,y,.66),(3.4,.12,.09),timber)
    for z in [.89,1.04,1.19,1.34]:box('Bench back slat',(0,.3,z),(3.4,.08,.12),timber)
    for x in [-1.4,1.4]:
        rod('Bench leg',(x,.1,.05),(x,.1,.65),.055,steel)
        rod('Bench back support',(x,.33,.45),(x,.33,1.42),.04,steel)
    box('Surrounding meadow',(0,3,-.27),(62,57,.18),green)
    for i in range(50):
        x=rng.uniform(-27,27);y=rng.uniform(7,25)
        h=rng.uniform(2.8,5.5)
        rod('Tree trunk',(x,y,0),(x,y,h*.7),.12,bark)
        ell('Leafy crown',(x,y,h),(.9+h*.13,.9+h*.1,h*.4),leaf)
    for i in range(38):
        x=rng.uniform(-16,16);y=rng.choice([-2.8,6])+rng.uniform(-.4,.4)
        ell('Roadside shrub',(x,y,.25),(.45,.4,.4),leaf)
    # Reference woman: long brown hair, navy jacket, ivory shirt and trousers.
    roots=[o for o in scene.objects if o.type=='EMPTY' and o.name.startswith('Woman ') and 'head' not in o.name]
    for root in roots:
        head=next((o for o in root.children if ' head' in o.name),None)
        if not head:continue
        for o in list(head.children):bpy.data.objects.remove(o,do_unlink=True)
        ell('Woman face',(0,0,0),(.18,.16,.235),skin,head)
        ell('Woman hair back',(0,.07,.02),(.205,.15,.28),hair,head)
        for side in [-1,1]:
            for i in range(5):
                lock=ell('Long wavy brown hair',(side*(.16+i*.007),.01+i*.017,-.12),(.045,.047,.27-i*.009),hair,head)
                lock.rotation_euler.y=side*.12
            ell('Woman eye',(side*.07,-.15,.035),(.025,.012,.017),ink,head)
            brow=box('Woman eyebrow',(side*.07,-.153,.084),(.059,.012,.011),hair,head);brow.rotation_euler.y=side*.12
            bang=ell('Side parted hair',(side*.095,-.06,.18),(.09,.11,.095),hair,head);bang.rotation_euler.y=side*.4
        ell('Woman nose',(0,-.163,-.025),(.022,.031,.045),skin,head)
        ell('Woman soft smile',(0,-.153,-.10),(.05,.012,.012),lip,head)
        for o in root.children:
            if o.type=='MESH' and ('torso' in o.name or 'Sleeve' in o.name):o.data.materials.clear();o.data.materials.append(navy)
        # Sleeves are children of animated arm pivots.
        for pivot in root.children:
            for o in pivot.children:
                if 'Sleeve' in o.name:o.data.materials.clear();o.data.materials.append(navy)
        box('Ivory blouse',(0,-.15,1.13),(.18,.025,.46),blouse,root)
        for side in [-1,1]:
            lapel=box('Navy lapel',(side*.13,-.18,1.18),(.09,.04,.40),navy,root);lapel.rotation_euler.y=side*.25
    # Studio speakers, MIDI keyboard, pads and a readable abstract DAW interface.
    for x in [38.9,41.1]:
        box('Studio speaker',(x,.35,1.55),(.42,.36,.75),black)
        for z,r in [(1.42,.13),(1.76,.065)]:ell('Speaker driver',(x,.155,z),(r,.035,r),ink)
        rod('Speaker stand',(x,.35,.1),(x,.35,1.2),.035,steel)
    box('MIDI keyboard',(40,-.02,1.01),(1.3,.3,.09),black)
    for i in range(22):
        x=39.39+i*.057;box('Piano white key',(x,-.06,1.065),(.052,.23,.018),blouse)
        if i%7 not in [2,6]:box('Piano black key',(x+.025,.01,1.09),(.029,.12,.025),black)
    box('Beat pad controller',(41,-.28,1.02),(.55,.45,.1),black)
    for i in range(4):
        for j in range(4):box('Lit performance pad',(40.81+i*.12,-.44+j*.1,1.08),(.09,.075,.015),violet if i%2 else amber)
    for o in scene.objects:
        if o.name=='Screen':o.data.materials.clear();o.data.materials.append(screen)
    for i in range(9):
        z=1.35+i*.06
        box('DAW track',(40,.309,z),(1.05,.005,.002),steel)
        for j in range(4):box('DAW clip',(39.52+j*.24,.302,z+.018),(.12+rng.random()*.08,.006,.033),cyan if i%2 else amber)
    for x in [38.6,41.4]:rod('Desk leg',(x,.2,0),(x,.2,.8),.045,steel)
    box('Studio side wall',(35,0,2.3),(.15,4,4.6),black)
    for x in [36,38,42,44]:
        for i in range(10):box('Acoustic panel ridge',(x-.55+i*.12,1.69,2.5),(.06,.08,1.8),navy)
    box('Studio chair seat',(40,-1.03,.6),(.65,.6,.12),black)
    box('Studio chair back',(40,-1.38,1.1),(.65,.12,.9),black)
    rod('Chair pedestal',(40,-1.03,.05),(40,-1.03,.6),.06,steel)
    # Festival truss structure, LED walls and suspended PA arrays.
    def truss(a,b):
        a=Vector(a);b=Vector(b);axis=(b-a).normalized();u=axis.cross(Vector((0,0,1)))
        if u.length<.1:u=axis.cross(Vector((0,1,0)))
        u.normalize();v=axis.cross(u).normalized();corners=[u*.16+v*.16,u*.16-v*.16,-u*.16-v*.16,-u*.16+v*.16]
        for c in corners:rod('Truss rail',a+c,b+c,.026,steel)
        count=max(1,int((b-a).length/.7))
        for i in range(count):
            aa=a+(b-a)*i/count;bb=a+(b-a)*(i+1)/count
            for j in range(4):rod('Truss diagonal',aa+corners[j],bb+corners[(j+1)%4],.016,steel)
    for x in [73,87]:
        for y in [-2.7,3]:truss((x,y,0),(x,y,9))
        truss((x,-2.7,9),(x,3,9))
    for y in [-2.7,0,3]:truss((73,y,9),(87,y,9))
    for x in [74,86]:
        for j in range(5):box('Hanging PA speaker',(x,1,7-j*.48),(.65,.65,.44),black)
    for x in [70.8,89.2]:
        box('Festival LED wall',(x,2,4.5),(2.8,.2,4.5),black)
        for i in range(9):
            box('LED wall graphic',(x-1.1+i*.27,1.88,4.5),(.12,.04,1+rng.random()*2.5),violet if i%2 else pink)
    for i in range(11):
        x=74+i*1.2
        ell('Festival lamp',(x,.3,7.5),(.14,.18,.14),violet if i%2 else pink)
        d=bpy.data.lights.new('Festival spotlight','SPOT');d.energy=500;d.color=(.5,.08,1) if i%2 else (1,.08,.25);d.spot_size=.65;d.spot_blend=.5
        o=bpy.data.objects.new('Festival spotlight',d);scene.collection.objects.link(o);o.location=(x,.4,7.5);o.rotation_euler=(Vector((80+(i-5)*2,10,0))-o.location).to_track_quat('-Z','Y').to_euler()
    text('LIVE',(80,2.9,6.2),1.2,violet)
    for x in [76,78,82,84]:box('Stage wedge monitor',(x,2,.95),(.8,.55,.4),black)
    for x in range(58,104):rod('Crowd barrier',(x,4.5,0),(x,4.5,1),.025,steel)
    rod('Barrier rail',(58,4.5,1),(103,4.5,1),.035,steel)
    # Linked duplicates retain cheering animation and the freeze hold.
    fans=[o for o in scene.objects if o.name.startswith('Cheering fan') and o.type=='EMPTY']
    for i in range(650):
        src=fans[i%len(fans)];root=src.copy();scene.collection.objects.link(root)
        root.location=(80+rng.uniform(-23,23),rng.uniform(5,35),0)
        root.scale=(rng.uniform(.85,1.1),)*3
        for child in src.children:
            dupe=child.copy();scene.collection.objects.link(dupe);dupe.parent=root
    # Slightly brighter outdoor fill; night concert relies on its own lamps.
    sun=bpy.data.lights.new('Evening sky fill','AREA');sun.energy=1600;sun.size=22;sun.color=(.55,.67,1)
    o=bpy.data.objects.new('Evening sky fill',sun);scene.collection.objects.link(o);o.location=(0,0,12)
